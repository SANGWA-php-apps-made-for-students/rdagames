<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>RWANDA GAMES</title>
        <link href="webstyles/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="index.php" method="post">
            <form action="index.php" method="post">
                <div class="box">  
                    <div class="contents">
                        <!--            <div id="body_left"> </div>-->

                        <?php
                        include './home_contents.php';
                        ?>
                        <?php
                        include 'Forms/footer.php';
                        ?>

                        <!--            <div id="body_right"></div> -->
                    </div>
                </div>
            </form>



            <script>
                function initMap() {
//                 var myLatLng = {lat: -25.363, lng: 131.044};
//                var myLatLng = {lat: - 1.90, lng: 29.944};
                    var myLatLng = {lat: -1.9706, lng: 30.1044};
                    var map = new google.maps.Map(document.getElementById('map'), {
                        zoom: 15,
                        center: myLatLng
                    });

                    var marker = new google.maps.Marker({
                        position: myLatLng,
                        map: map,
                        title: 'Glory to God Main Church'
                    });
                }
            </script>
            <script async defer
                    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap">
            </script> 
            <script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
            <script src="js/scripts.js" type="text/javascript"></script>


    </body>
</html>
