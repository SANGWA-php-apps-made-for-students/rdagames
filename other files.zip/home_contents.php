<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="header">
            <div class="logo">
            </div>	
            <div class="title">
                <span class="title_p1">RWANDA</span>
                <span class="title_p2">GAMES</span>
            </div>
            <div class="login_register">
                <div class="moving_text"><marquee>Gaming world</marquee></div>
                <a href="accounts/newuser.php">Register</a>
                <a href="accounts/login.php">Login</a>
            </div>
        </div>
        
        <span>.
            <?php
            include 'menuItems.php';
            ?>
        </span>
<div class="slide parts">
            <?php
            include './Forms/other_parts/slideItems/pictures.php';
            ?>
        </div>
        






    </body>
</html>
