<div class="menu">
    <a href="index.php">Home</a>
    <a href="Forms/Aboutus.php">About us</a>
    <a href="Forms/news.php">News</a>
    <a href="Forms/Gaming_centers.php">Gaming centers</a>
    <a href="Forms/carrier.php">Careers</a>
    <a href="Forms/Partners.php">Partners</a>
    <a href="Forms/Contactus.php">Contact us</a>
</div>
