<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        
    </head>
    <body>
        <div class="box">  
            <div class="contents">
           <div class="header">
                    <div class="logo">

                    </div>	
                    <div class="title">
                        <span class="title_p1">RWANDA</span>
                        <span class="title_p2">GAMES</span>
                    </div>
                    <div class="login_register">
                        <div class="moving_text"><marquee>Gaming world</marquee></div>
                        <a href="accounts/newuser.php">Register</a>
                        <a href="accounts/login.php">Login</a>

                    </div>
                </div>
                <div class="menu">
                    <a id="home_link" href="index.php" class="home_menu" >
                        Home</a>
                    
                    <a href="Forms/Aboutus.php">About us</a>
                    <a href="Forms/news.php">News</a>
                    <a href="Forms/Gaming_centers.php">Gaming Centres</a>
                    <a href="Forms/carrier.php">Career</a>
                    <a href="Forms/Partners.php">Partners</a>
                    <a href="Forms/Contactus.php">Contact us</a>
                </div>
                
                <div class="two_pictures">
                    <a href="../Forms/mpeaceplazagallery.php">
                        <div class="pic1" name="pic1"></div>
                    </a>
                    <div class="pic2">
                        
                    </div>
                </div>

                <div class="white_titles">
                    Get different matches 
                    <div class="small_font">
                        Small fonts
                    </div>
                </div>
                <div class="slide_box">

                    <div id="slide_pic1" class="Events">
                        <span id="test_paragraph"></span>
                        <div class="sliding_text" style="overflow: auto;">

                        </div>
                    </div>
                    <div id="slide_pic2" class="Events">
                        <span id="test_paragraph">Earn on every bet</span>
                        <div class="sliding_text"></div>

                    </div>  

                    <div id="slide_pic3" class="Events">
                        <span id="test_paragraph">It is all about riches and fun</span>
                        <div class="sliding_text"></div>

                    </div> 

                    <a href="Forms/adverts.php">
                         <div class="job_anouncement">

                    </div>
                    </a>
                   
                    <div class="job_disc">
                        <div class="job_arrow"></div>
                        <div class="job_ann_content">
                           Click and view available jobs
                        </div>
                    </div>


                </div>
                <div class="sport_desc">
                    <div class="white_titles">Types of sports</div>
                    <h2>You can bet on:</h2>
                    <div class="ball_icon">
                        <div id="football_icon">
                        </div>
                        <div class="ball_icon_description" style="overflow: auto;">
                            Bet on every football match

                        </div>
                    </div>
                    <div class="ball_icon">
                        <div id="volleyball_icon">

                        </div>
                        <div class="ball_icon_description">Get connected with Volley ball channels</div>
                    </div>

                    <div class="ball_icon">		
                        <div id="basketball_icon">

                        </div>
                        <div class="ball_icon_description">Know real-time matches</div>
                    </div>
                    <div class="ball_icon">
                        <div id="horses_icon">

                        </div>
                        <div class="ball_icon_description">Don't miss out interesting horse races</div>
                    </div>
                    <div style="width: inherit; padding: 6px; float: right">

                    </div>

                </div>
                <div class="types_sports">

                </div>
                <div class="white_titles">Odds</div>
                <div class="Odds">
                    <table border="0">
                        <thead >
                            <tr>
                                <th>Team A</th>
                                <th>Team B</th>
                                <th>Country</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1.5</td>
                                <td>2.5</td>
                                <td>France</td>
                                <td>2016-07-10</td>
                            </tr>
                            <tr>
                                <td>4.6</td>
                                <td>6.1</td>
                                <td>England</td>
                                <td>2016-07-10</td>
                            </tr>
                            <tr>
                                <td>4.6</td>
                                <td>6.1</td>
                                <td>England</td>
                                <td>2016-07-10</td>
                            </tr>
                            <tr>
                                <td>1.5</td>
                                <td>2.5</td>
                                <td>France</td>
                                <td>2016-07-10</td>
                            </tr>
                            <tr>
                                <td>1.5</td>
                                <td>2.5</td>
                                <td>France</td>
                                <td>2016-07-10</td>
                            </tr>
                        </tbody>
                    </table>

                </div>


            </div>




    </body>
</html>
