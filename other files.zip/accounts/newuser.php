<!DOCTYPE html>
<html>
    <head>
        <title>Register</title>

        <link href="../webstyles/styles.css" rel="stylesheet" type="text/css"/>

        <link rel="icon" href="images/rg_icon.png">
    </head>
    <body>
        <form action="newuser.php" method="post">
            <div class="box">
                <div class="contents">
                    <?php
                    include 'index.php';
                    if (isset($_POST['send'])) {

                        $name = $_POST['name'];
                        $surname = $_POST['surname'];
                        $email = $_POST['email'];
                        $username = $_POST['username'];
                        $password = $_POST['password'];
                        $phone = $_POST['phone'];
                        $category = 8;
                        $con = mysql_connect('localhost', 'root', '') or die(mysql_error());
                        mysql_select_db('rdausersmanagement')or die(mysql_error());
                        
                        $query = "insert into users values(null,'$name','$surname','$email','$username','$password','$phone','$category')" or die(mysql_error());
                        mysql_query($query)or die(mysql_error());
                        mysql_close($con);
                        ?>
                    
                    <div style="background-color: #2bc54d;display: inline-block;margin-top: 8px;color: #fff; padding: 10px;"><?php
                        echo "Data saved successfully";
                        ?>
                    </div><?php
                    }
                    ?>

                    <div class="pane" style="width: 600px;margin-top: 80px;">
                        <div class="pane_title" >Sign Up For Account</div>
                        <div class="pane_content">
                            <table  >
                                <tbody>
                                    <tr>
                                        <td> 
                                            <p class="no_left_margin">Name:
                                                <input type="text" name="name" class="textinput" id="name" placeholder="Enter Name">
                                            </p>
                                        </td>
                                        <td> 
                                            <p class="no_left_margin">Surname:	
                                                <input type="text" name="surname" class="textinput" id="surname" placeholder="Enter Surname">
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="no_left_margin">Email:	
                                                <input type="text" name="email" class="textinput" id="email" placeholder="Enter email">
                                            </p>
                                        </td>
                                        <td>
                                            <p class="no_left_margin">	Username:
                                                <input type="text" name="username" class="textinput" id="username" placeholder="Enter username">
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <p class="no_left_margin">	Password:
                                                <input type="password" name="password" class="textinput" id="password" placeholder="Enter Password">
                                            </p>
                                        </td>
                                        <td>
                                            <p class="no_left_margin">	Phone:
                                                <input type="text" name="phone" class="textinput" id="phone" placeholder="(country code)(number)">
                                            </p>
                                        </td>
                                        
                                        </tr>
                                            <tr>
                                        
                                        <td> 
                                            <input type="submit" class="yellow_buttons"  id="send" name="send" value="Register">
                                        </td>
                                        
                                    </tr>
                                </tbody>
                            </table>

                            
                        </div>
                    </div>
                </div>
                <?php include('../Forms/footer.php'); ?>	
            </div>	

        </form>
        <script src="../js/jquery-1.9.1.min.js" type="text/javascript"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('a').click(function () {
                    var link = $(this).attr('href');
                    $.post('tracks/newtrack.php', {link: link}, function (data) {
                        // $(".display").text('returned data is:  '+data);
                        $('.contents').load(link);

                    });
                });

                $('#send').click(function () {
                    var name = $('#name').val();
                    var surname = $('#surname').val();
                    var email = $('#email').val(),
                    password=$('#password').val(),
                    username=$('#username').val(),
                    phone=$('#phone').val();

                if (name == '' || surname=='' || email==''|| password==''||phone=='') {
                        alert('all the fields must be filled '  );
                        return false;
                        
                    }
                });

            });
        </script>

    </body>
</html>


