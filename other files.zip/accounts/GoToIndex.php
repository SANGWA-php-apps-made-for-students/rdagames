<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<div class="header">
		<div class="logo">
		
		</div>	
		<div class="title">
			<span class="title_p1">RWANDA</span>
			<span class="title_p2">GAMES</span>
		</div>
		<div class="moving_text"><marquee>Gaming world</marquee></div>
		<div class="login_register">
			<a href="newuser.php" class="login_register">Register</a>
			<a href="login.php" class="login_register">login</a>
		</div>
	</div>
	<div class="menu">
		<a href="../index.php" class="home_menu">
				Home</a>
		<a href="../Aboutus.php">About us</a>
		<a href="../news.php">News</a>
		<a href="../Gaming_centers.php">Gaming Centres</a>
		<a href="#">Career</a>
		<a href="../Partners.php">Partners</a>
		<a href="../Contactus.php">Contact us</a>
		
	</div>

 </body>
</html>
