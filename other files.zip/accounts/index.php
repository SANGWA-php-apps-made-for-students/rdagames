<?php
 if(isset($_GET['success']))
 {
  ?>
        <label>File Uploaded Successfully...  
        <a href="view.php">click here to view file.</a></label>
        <?php
 }
 else if(isset($_GET['fail']))
 {
  ?>
        <label>Problem While File Uploading !</label>
        <?php
 }
 else
 {
  ?>
        
        <?php
 }
 ?>

<!DOCTYPE html>

<head>

<link rel="stylesheet" type="text/css" href="styles.css">
<link rel="icon" href="images/rg_icon.png">
<title>

</title>


</head>

<body oncontextmenu="return false" >

     <div class="header">
                    <div class="logo">
                    </div>	
                    <div class="title">
                        <span class="title_p1">RWANDA</span>
                        <span class="title_p2">GAMES</span>
                    </div>
                    <div class="login_register">
                        <div class="moving_text"><marquee>Gaming world</marquee></div>
                        <a href="newuser.php">Register</a>
                        <a href="login.php">Login</a>
                       
                       

                    </div>
                </div>
         <div class="menu">
            
             <a href="../index.php">Home</a>
             <a href="../Forms/Aboutus.php">About us</a>
             <a href="../Forms/news.php">News</a>
             <a href="../Forms/Gaming_centers.php">Gaming Centres</a>
             <a href="../Forms/carrier.php">Career</a>
             <a href="../Forms/Partners.php">Partners</a>
             <a href="../Forms/Contactus.php">Contact us</a>
            </div>

</body>
</html>