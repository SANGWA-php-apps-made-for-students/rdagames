<?php 
 session_start();
 
unset($_SESSION['session_set']);
session_destroy();
header('location:../index.php');
?>