


<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link href="../webstyles/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form method="post" action="login.php">
            <div class="box">	
                <div class="contents" style="overflow-x: hidden;">

                    <?php
                    include 'index.php';
                    if (isset($_POST['send'])) {
                        $userName = $_POST['username'];
                        $password = $_POST['password'];

                        require_once '../Forms/db/connection.php';
                        require_once '../Forms/db/multi_records.php';
                        require_once '../Forms/db/uni_records.php';

                        $con = dbconnection::con_users();
                        $query1 = "SELECT * FROM users where username='$userName' and userpass='$password'";
                        $res1 = mysql_query($query1) or die(mysql_error());
                        if ($row = mysql_fetch_array($res1)) {
                            $names = multi_records::get_names_by_username_pass($userName, $password);
                            $user_id = unirecords::getuseridby_username_pass($userName, $password);

                            $query2 = "SELECT category_id FROM users where username='$userName' and userpass='$password'  ";
                            $res2 = mysql_query($query2) or die(mysql_error());
                            if ($row = mysql_fetch_array($res2)) {
                                $user_category = $row['category_id'];
                                if ($user_category == '1' || $user_category == '2') {
                                    //Lead the user to the appropriate page. this for the GD and IT
                                    session_start();
                                    $_SESSION['session_set'] = $user_category;
                                    $_SESSION['names'] = $names;
                                    $_SESSION['userid'] = $user_id;
                                    //echo $_SESSION['admin'];
                                    header('Location: ../Forms/GD/GD_home.php');
                                } else {
                                    session_start();
                                    $_SESSION['session_set'] = $user_category;
                                    $_SESSION['names'] = $names;
                                    $_SESSION['userid'] = $user_id;
                                    header('Location:../Forms/pub_users/pub_users_homepage.php');
                                }
                            } else {
                                echo "At this point the category cant be found. sorry try again.";
                            }
                        } else {
                            ?><div style="color:#ff0000; font-weight: bolder; font-size:15px; font-family: Segoe UI;
                                 margin: auto; width: 50%;margin-bottom:30px;margin-top:10px;"><?php
                                 echo "username or password are invalid";
                                 ?></div><?php
                        }
                    }
                    //save in the reservation
                    ?>
                    <div class="pane" style="float: left; margin-left: 100px;">
                        <div class="pane_title">Login</div>
                        <div class="pane_content">

                            <p class="no_left_margin">				Username:</p>
                            <input type="text" class="textinput" placeholder="Enter username" name="username">
                            <p class="no_left_margin">	Password:</p>
                            <input type="password" class="textinput" placeholder="Enter password" name="password">

                            <input class="yellow_buttons" type="submit" value="Login" style="width:100%;" name="send">
                        </div>
                    </div>
                    <div class="pane" style="font-size: 16px;  box-shadow: none;margin-left: 50px; float: left; margin-top: 200px;  text-shadow: 0 0 2px #FF0000, 0 0 2px #0000FF;">
                        Or sign in with =>
                    </div>
                    <div class="pane" style="font-size: 16px;background-color: #fff;  box-shadow: 0px 0px 10px #7db85f ;margin-left: 10px; float: left; margin-top: 20px;min-height: 100px; border: 1px solid #edac2d;width: 150px;">
                        <div class="Login_plugin" id="Facebook_login"><a href="#">
                            </a>
                            <input id="login-info-face" type="submit" class="login-btn Login_plugin_btn" value=""/>
                            <span id="login-info">
                                <a href="../Forms/pub_users/pub_users_homepage.php"></a>
                            </span>
                        </div>
                        <div class="Login_plugin" id="goolge_login"> 
                            <a href="google_login.php"> 
                                <input  type="submit" id="login-info-google" class="login-btn Login_plugin_btn" value=""/>
                                Google +
                            </a>

                            <span id="login-info">

                            </span>
                        </div>

                        <div class="Login_plugin" id="twitter_login"> <a href="#">
                                <input  type="submit" id="login-info-twitter" class="login-btn Login_plugin_btn" value=""/>
                                Twitter</a> <span id="login-info">
                            </span>
                        </div>
                    </div>
                </div>
                <?php include('../Forms/footer.php'); ?>	
            </div>	
        </form>
        <script src="../js/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script type="text/javascript">

            $(document).ready(function () {
                $.ajaxSetup({cache: true});
                $.getScript('//connect.facebook.net/en_US/sdk.js', function () {
                    FB.init({
                        appId: '1606031006354656',
                        cookie: true,
                        version: 'v2.6' // or v2.1, v2.2, v2.3, ...
                    });
                    refreshStatus();

                    $("#login-info-face").click(function (e) {
                        e.preventDefault();
                        FB.login(
                                function (response) {
                                    console.log(response);
                                    refreshStatus();

                                },
                                {
                                    scope: 'public_profile,email',
                                    auth_type: 'rerequest'
                                }
                        );
                    });


                });
                //other plugins
                gmail_click();
                twitter_login();
                face_login();
            });

            refreshStatus = function ()
            {
                FB.getLoginStatus(function (st) {
                    var info = $('#login-info').html();
                    if (st.status == "connected")
                    {
                        getInfo();
                        $(".login-btn").attr("disabled", "disabled");
//                         window.location = "http://www.rwandagames.co.rw/pub_users/pub_users_homepage.php";
                    } else {
                        $(".login-btn").removeAttr("disabled");

                    }

                });
            };

            getInfo = function ()
            {
                FB.api("/me", function (data) {
                    console.log(data);
                    $("#Facebook_login > span").html(data.name);

                    $('.id-info').html(data.id);
                    var names = ('#Facebook_login > span').html(data.name);
                    //insert session

                });
            };


            function face_login() {
                $('#Facebook_login > span').click(function () {

                    //window.location.replace("http://localhost/RdagamesN/Forms/pub_users/pub_users_homepage.php");
                  
//                    var thenames=$("#Facebook_login > span").html(data.name);
//                    $.post('login.php', {thenames:thenames}, function (data) {
                       alert(thenames);
                        
//                    });

                });
            }

            function gmail_click() {
                $('#login-info-google').click(function () {
                    return false;
                });


            }
            function twitter_login() {
                $('#login-info-twitter').click(function () {
                    return false;
                });

            }

        </script>

    </body>
</html>