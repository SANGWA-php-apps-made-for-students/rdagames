
var counter=0;
var ball_counter=0;

$(document).ready(function(){
//	changeText();
//	fadeAfter_7_seconds();
//	test_paragraph();
//	
//	var margin_above=$('.Events').height()/2;
//	$('.sliding_text ').css('marginTop',margin_above);
//       // Slide_show_slide_pictures();
//        Highlight_job();
//        rotate_balls();
//        
//        
//        apply_clicked_public();
        slider();
        
});

function Slide_show_slide_pictures(){
    $('#body_left, #body_right').show(1200);
}
 function showInitial_image(){
 	//hide all
 	$('#slide_pic1').hide();
 	$('#slide_pic2').show();
 	 
 }

function test_paragraph(){
	setTimeout(function(){
		$('#test_paragraph').animate({marginLeft:'-=30',position:'relative'},1800);
		$('#test_paragraph').animate({marginLeft:'+=30',position:'relative'},1800);
		
		test_paragraph();

 
	},1000);
}

//function fadeAfter_7_seconds(){
// setTimeout(function(){
// 	if (counter==6) {};
// 		$('#test_paragraph').fadeOut(600).fadeIn(600);
// 	 fadeAfter_7_seconds();
// },7000);
//
//}
function changeText(){
	setTimeout(function(){
		counter+=1;
		if (counter==24) {
			counter=0;
			
		}
		if (counter>0 && counter<=13) {
			
			 //change 
                        $('#slide_pic1').css('z-index','1');
                        
			$('#slide_pic1').fadeOut(500);
			$('#slide_pic3').fadeOut(500);
 			$('#slide_pic2').fadeIn(500);


		}else if (counter>13 && counter<=26) {
			//change and put the second picture
			 $('#slide_pic2').fadeOut(500);
			 $('#slide_pic3').fadeOut(500);
 			$('#slide_pic1').fadeIn(500);
			$('#test_paragraph').html('');
			$('#test_paragraph').html('Start betting and get rich');
			//Change_Slider_InnerText('This is your time for bet..');

		}else if (counter>39 && counter<=42) {
			$('#slide_pic1').fadeOut(500);
			$('#slide_pic2').fadeOut(500);
			$('#slide_pic3').fadeIn(500);
			//Change_Slider_InnerText('This is your time for bet...');
		}
		if (counter==1) {
			$('.sliding_text').css('margin-left','300px');
			$('.sliding_text').animate({marginLeft: '-=300px',position:'relative'},2000).html('if you have ever heard of betting or not');
//		
					}
		if (counter==7) {
                    Highlight_job();
			$('.sliding_text').css('margin-left','300px');
			$('.sliding_text').animate({marginLeft: '-=300px',position:'relative'},2000).html('Familiar or not');
//			
		}
		if (counter==14) {
                    Highlight_job();
			$('.sliding_text').css('margin-left','300px');
			$('.sliding_text').animate({marginLeft: '-=300px',position:'relative'},2000).html('Still you can easily bet');
//			
		}
		changeText();
	},1000);
}

function Change_Slider_InnerText(txt){
        $('.sliding_text').animate({marginRight: '+=100px',position:'relative'}).html(txt);
		$('.sliding_text').animate({marginRight: '-=100px',position:'relative'});
		
	
}

function hide_Slider_InnerText(){
	$('.sliding_text').hide();
}


function highlighter_hoz(){
	setTimeout(function(){

		$('.highlighter_hoz').animate({marginLeft:'-=30',position:'relative'});
		$('.highlighter_hoz').animate({marginLeft:'+=30',position:'relative'});
		highlighter_hoz();
	},2000);
}

function ShowContactus(){
	$('#info_link').click(function(){
		$('#info_expanding_pane').slideDown(500);
	});
}
function Highlight_job(){
    $('.job_disc').animate({opacity:'0.5'},1000).animate({ opacity:'1' },1000);
}
function rotate_balls(){
    $('#football_icon').click(function(){
        alert('the ball is clicked');
        $('#football_icon').css({ rotate: '30deg' });
    });
     $('#football_icon, #basketball_icon, #volleyball_icon,#volleyball_icon').css({ rotate: '30000deg' });
}
function ball_bouncer(){
     	setTimeout(function(){
            if (ball_counter==5) {
            $('#football_icon').addClass(bounce_football);
        }
        ball_bouncer();
	},1000);
}

function apply_clicked_public(){
    $('.apply_button').click(function(){
       alert('public clicked') ;
    });
}

function slider() {
    setTimeout(function () {
        counter += 1;
       
        if (counter == 1) {
            
            $('#pic8').animate({zIndex: '1'});
            $('#pic7').animate({zIndex: '2'});
            $('#pic6').animate({zIndex: '3'});
            $('#pic5').animate({zIndex: '4'});
            $('#pic4').animate({zIndex: '5'});
            $('#pic3').animate({zIndex: '6'});
            $('#pic2').animate({zIndex: '7'});
            $('#pic1').animate({zIndex: '9',left:'+=10'}).animate({left:'-=10'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');
            $('#pic9').animate({zIndex:'8'});

        } else if (counter == 10) {
            $('#pic8').animate({zIndex: '1'});
            $('#pic7').animate({zIndex: '2'});
            $('#pic6').animate({zIndex: '3'});
            $('#pic5').animate({zIndex: '4'});
            $('#pic4').animate({zIndex: '5'});
            $('#pic3').animate({zIndex: '6'});
            $('#pic1').animate({zIndex: '7'}).removeClass('pics_shade');
            $('#pic2').animate({zIndex: '9',left:'+=60'}).animate({left:'-=60'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');
            $('#pic9').animate({zIndex:'8'});
        } else if (counter == 15) {
            $('#pic8').animate({zIndex: '1'});
            $('#pic7').animate({zIndex: '2'});
            $('#pic6').animate({zIndex: '3'});
            $('#pic5').animate({zIndex: '4'});
            $('#pic4').animate({zIndex: '5'});
            $('#pic1').animate({zIndex: '6'});
            $('#pic2').animate({zIndex: '7'}).removeClass('pics_shade');;
            $('#pic3').animate({zIndex: '9',left:'+=60'}).animate({left:'-=60'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');;
            $('#pic9').animate({zIndex:'8'});
        } else if (counter == 20) {
            $('#pic8').animate({zIndex: '1'});
            $('#pic7').animate({zIndex: '2'});
            $('#pic6').animate({zIndex: '3'});
            $('#pic5').animate({zIndex: '4'});
            $('#pic1').animate({zIndex: '5'});
            $('#pic2').animate({zIndex: '6'});
            $('#pic3').animate({zIndex: '7'}).removeClass('pics_shade');;
            $('#pic4').animate({zIndex: '9',left:'+=60'}).animate({left:'-=60'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');;
            $('#pic9').animate({zIndex:'8'});
        } else if (counter == 25) {
            $('#pic8').animate({zIndex: '1'});
            $('#pic7').animate({zIndex: '2'});
            $('#pic6').animate({zIndex: '3'});
            $('#pic1').animate({zIndex: '4'});
            $('#pic2').animate({zIndex: '5'});
            $('#pic3').animate({zIndex: '6'});
            $('#pic4').animate({zIndex: '7'}).removeClass('pics_shade');;
            $('#pic5').animate({zIndex: '9',left:'+=60'}).animate({left:'-=60'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');;
            $('#pic9').animate({zIndex:'8'});
        } else if (counter == 30) {
            $('#pic8').animate({zIndex: '1'});
            $('#pic7').animate({zIndex: '2'});
            $('#pic1').animate({zIndex: '3'});
            $('#pic2').animate({zIndex: '4'});
            $('#pic3').animate({zIndex: '5'});
            $('#pic4').animate({zIndex: '6'});
            $('#pic5').animate({zIndex: '7'}).removeClass('pics_shade');;
            $('#pic6').animate({zIndex: '9',left:'+=60'}).animate({left:'-=60'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');;
            $('#pic9').animate({zIndex:'8'});
        } else if (counter == 35) {
            $('#pic8').animate({zIndex: '1'});
            $('#pic1').animate({zIndex: '2'});
            $('#pic2').animate({zIndex: '3'});
            $('#pic3').animate({zIndex: '4'});
            $('#pic4').animate({zIndex: '5'});
            $('#pic5').animate({zIndex: '6'});
            $('#pic6').animate({zIndex: '7'}).removeClass('pics_shade');;
            $('#pic7').animate({zIndex: '9',left:'+=60'}).animate({left:'-=60'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');;
            $('#pic9').animate({zIndex:'8'});
        } else if (counter == 40) {
            $('#pic1').animate({zIndex: '1'});
            $('#pic2').animate({zIndex: '2'});
            $('#pic3').animate({zIndex: '3'});
            $('#pic4').animate({zIndex: '4'});
            $('#pic5').animate({zIndex: '5'});
            $('#pic6').animate({zIndex: '6'});
            $('#pic7').animate({zIndex: '7'}).removeClass('pics_shade');;
            $('#pic8').animate({zIndex: '9',left:'+=60'}).animate({left:'-=60'})
                    .animate({left:'+=5'},300).animate({left:'-=5'},300).addClass('pics_shade');;
           $('#pic9').animate({zIndex:'8'});
        }else if (counter==45) {
             counter = 0;
        }
        $('.slide_pics').css('color', '#000');
        slider();
    }, 1000);


}


function showPic1() {
    $('#pic1').animate({zIndex: '1'}, 2500);

}
function showPic2() {

}
function showPic3() {

}
function showPic4() {

}
function showPic5() {

}
function showPic6() {

}
function showPic7() {

}
function showPic8() {

}
