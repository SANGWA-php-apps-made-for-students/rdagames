<?php
if (!isset($_SESSION)) {
    session_start();
    if (isset($_POST['send'])) {

        //save in the reservation


        $con = mysql_connect('localhost', 'usersuser', 'users@user!123') or die(mysql_error());
        mysql_select_db('usersmanagement')or die(mysql_error());
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            Partners
        </title>
        <link rel="stylesheet" type="text/css" href="../webstyles/styles.css">
        <link rel="icon"  href="images/rg_icon.png">

        <style type="text/css">
            .carrier{
                clear: none;
                height: 100px;
                padding: 5px;
                background-color:  #fff;
                overflow: hidden;
                border: 2px solid #cdcdec;

            }
            .carrier_left{
                float: left;
                background-image: url('../images/dice_image.png');
                height: 100px;
                width: 100px;
                background-size: 100%;
            }
            .carrier_right{
                float: right;
                background-image: url('../images/money_inhand.png');
                height: 100px;
                width: 100px;
                background-size: 100%;
            }
            .carrier_text{
                margin: auto;
                text-align: center;
                font-size: 20px;
                font-weight: 700;
            }
        </style>
    </head>
    <body>
        <form action="Partners.php" method="post">

            <div class="box">
 <div class="contents">
              <?php include './menuToall.php';?>
               
                    <h2>You are welcome to grow you business with us</h2>
                    <div class="paragraph">
                        You can come and join our experts 
                    </div>
                    <div class="carrier">

                        <div class="carrier_left"></div>
                        <div class="carrier_text">Alone we can do so little, together we can do so much </div>
                        <div class="carrier_right"></div>
                    </div>


                </div>
                
                <div>
                </div>
                <?php include('footer.php'); ?> 
            </div>

        </form>
        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="scripts.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('a').click(function () {
                    var link = $(this).attr('href');
                    $.post('tracks/newtrack.php', {link: link}, function (data) {
                        // $(".display").text('returned data is:  '+data);
                        $('.contents').load(link);

                    });
                })
            });


        </script>


    </body>
</html>