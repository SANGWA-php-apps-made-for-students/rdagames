<!DOCTYPE html>
<html>
    <head>
        <title>
            Partners
        </title>
        <link rel="stylesheet" type="text/css" href="../webstyles/styles.css">
        <link rel="icon"  href="images/rg_icon.png">
        <style type="text/css">
            .guinee_bullet_link{
                background-image: url('images/guinee_games_bullet.PNG');
                background-repeat: no-repeat;		
                list-style: none;

            }
            .guinee_bullet_link a{
                padding: 16px;
            }
        </style>
    </head>
    <body>
        <form action="Partners">
            <div class="box">
                <div class="contents">

                    <?php include './menuToall.php'; ?>
                    <div class="big_titles" style="margin-top:70px;">Our partners</div>
                    <a target="_blank" href="http://www.guineegames.com">
                        <div class="guinne_logo" style="float: left;"> 
                        </div>
                    </a>
                    
                        <div class="pane" >
                            <div class="pane_title" style="font-weight: 500;">
                                Discover Guinee Games
                            </div>
                            <div class="pane_content" style="font-family: bantag;">

                                <ul>
                                    <li class="guinee_bullet_link">
                                        <a href="http://www.guineegames.com/pdf/long-list.pdf">
                                            <span style="margin-left: 20px;">Get the list of all Matches	</span>							</a>
                                    </li>
                                    <li class="guinee_bullet_link">
                                        <a href="http://www.guineegames.com/pdf/long-list-results.pdf">
                                            <span style="margin-left: 20px;">Get the list of Matches	results	</span>						</a>
                                    </li>


                                    <li class="guinee_bullet_link">
                                        <a href="http://www.guineegames.com/pdf/long-list.pdf">
                                            <span style="margin-left: 20px;">Get the list of Matches	</span>							</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                   


                </div>
                <?php include('footer.php'); ?> 
            </div>









        </form>
        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="scripts.js"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('a').click(function () {
                    var link = $(this).attr('href');
                    $.post('tracks/newtrack.php', {link: link}, function (data) {
                        // $(".display").text('returned data is:  '+data);
                        $('.contents').load(link);

                    });
                })
            });
        </script>
    </body>
</html>