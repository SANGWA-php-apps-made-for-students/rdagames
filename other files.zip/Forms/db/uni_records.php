<?php

    if (!class_exists('dbconnection')) {
        require 'connection.php';
        $con = dbconnection::con_job();
    }

    class unirecords {

        function getuseridby_username_pass($username, $password) {
            $con = dbconnection::con_users();
            $query = "select userid from users where username='$username' and userpass='$password'" or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {

                $userid = $row['userid'];
            }
            return $userid;
        }

        function getjob_category_id($name) {

            $jobcat = '';
            $con = dbconnection::con_job();
            $query = "select category_id from job_category where name  ='$name'" or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {

                $jobcat = $row['category_id'];
                echo 'the job id is: ' . $jobcat;
            }
            // echo 'the id is:  '. $jobcat;
        }

        function getjob_id($title) {
            $jobid;
            $con = dbconnection::con_job();
            $query = "select position_id from job where title  ='$title'" or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {

                $jobid = $row['position_id'];
            }
            return $jobid;
        }

        //get_user_in_cv
        function get_user_in_jobs($userid) {
            $userid;
            $con = dbconnection::con_job();
            $query = "select user_id from job_user where user_id  ='$userid'" or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $userid = $row['user_id'];
            }
            return $userid;
        }

        function get_cv_id_in_cv($userid) {

            $cv_id = '';
            $con = dbconnection::con_job();
            $query = "select cv.cv_id from cv join applicant_basics on cv.applicant_id=applicant_basics.applicant_id  where applicant_basics.user_account='$userid'   " or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $cv_id = $row['cv_id'];
            }
            return $cv_id;
        }

        function get_applicantion_id_by_login_id($userid) {
            $app_id = 0;
            $con = dbconnection::con_job();
            $query = "select applicant_id from applicant_basics where user_account  ='$userid'" or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {

                $app_id = $row['applicant_id'];
            }
            return $app_id;
        }

        function get_last_appliacant() {

            $applicant_id = '';
            $con = dbconnection::con_job();
            // get the category id by name
            $query = "SELECT applicant_id from applicant_basics order by applicant_id desc  limit 1 "or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $applicant_id = $row['applicant_id'];
            }
            return $applicant_id;
        }

        function get_last_cv() {
            $names;
            $con = dbconnection::con_job();
            // get the category id by name
            $query = "SELECT cv_id from cv order by cv_id desc  limit 1 "or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $names = $row['cv_id'];
            }
            return $names;
        }

        function get_name($userid) {

            $names = '';
            $con = dbconnection::con_job();
            // get the category id by name
            $query = "SELECT applicant_basics.names from applicant_basics where user_account='$userid' "or die(mysql_error());

            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $names = $row['names'];
            }
            return $names;
        }

        function applicants_by_job($job_id) {
            $tot_users = '';
            $n = 0;
            $con = dbconnection::con_job();
            // get the category id by name
            $query = "select job_user.user_id from job_user join job on job.position_id=job_user.job_id where job.position_id='$job_id' "or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $tot_users = $row['user_id'];
                $n += 1;
            }
            return $n;
        }

        function get_if_applied($user) {

            $con = dbconnection::con_job();
            $tot_user = 0;
            $query = "select user_account from applicant_basics join job_user on job_user.user_id=applicant_basics.applicant_id where applicant_basics.user_account='$user' limit 1 "or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $tot_users = $row['user_account'];
            }
            return $tot_user;
        }

        function gey_if_applied_on_ajob($userid, $jobid) {
            $con = dbconnection::con_job();
            $job_id = 0;
            $query = "select job_id from job_user where user_id='$userid' and job_id='$jobid' " or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $tot_users = $row['job_id'];
            }
            return $job_id;
        }

        function get_tot_jobs() {
            $tot = 0;
            $query = "select  count(*) as Total from job"or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $tot = $row['Total'];
            }
            return $tot;
        }

        function get_tot_applicants() {
//        require 'connection.php';
            $con = dbconnection::con_job();
            $tot = 0;
            $query = "select count(*) as Total from applicant_basics "or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $tot = $row['Total'];
            }
            return $tot;
        }

        function get_tot_Staff() {
//        require 'connection.php';
            $con = dbconnection::con_job();
            $tot = 0;
            $query = "select count(*) as Total from job_user where application_status='accepted' "or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $tot = $row['Total'];
            }
            return $tot;
        }

        function number_of_job_per_user($userid) {
            $con = dbconnection::con_job();
            $tot = 0;
            $query = "select count(job_id) as Total from job_user join applicant_basics on applicant_basics.applicant_id=job_user.user_id where applicant_basics.user_account='$userid' "or die(mysql_error());
            $res1 = mysql_query($query)or die(mysql_error());
            while ($row = mysql_fetch_array($res1)) {
                $tot = $row['Total'];
            }
            return $tot;
        }

    }
    