<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of update
 *
 * @author SANGWA
 */
class update {
 
    function republish_job($jobid){
           $query = "update job set job_status='available' where position_id='$jobid'" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'job published succefully';
    }
    function Remove_job($jobid){
         $query = "update job set job_status='unavailable' where position_id='$jobid'" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo'Job removed';
    }
      function Confirm_Application($job_id,$userid){
         $query = "update job_user set application_status='accepted' where job_id='$job_id' and user_id='$userid'" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo'Application accepted';
    }
    
}
