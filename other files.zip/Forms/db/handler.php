<?php

include ('new_records.php');
include ('multi_records.php');
include ('uni_records.php');
include ('delete.php');
include ('update.php');

if (isset($_POST['request'])) {
    $request = $_POST['request'];

    if ($request == 'new') {
        if ($_POST['method'] == 'newjob_post') {
            $savepost = new_records::newjob_post($_POST['title'], $_POST['id'], $_POST['job_status'], $_POST['description']);
        }
        if ($_POST['method'] == 'newcv') {

            $names = $_POST['names'];
            $usernumber = $_POST['usernumber'];
            $date_birth = $_POST['date_birth'];
            $residence_city = $_POST['residence_city'];
                        $national_id = $_POST['national_id'];
            $sex = $_POST['sex'];
            $father = $_POST['father'];
            $mother = $_POST['mother'];
            $nationality = $_POST['nationality'];
            $language=$_POST['language'];

//the education
            $grade = $_POST['grade'];
            $grade_name = $_POST['grade_name'];
            $edu_place = $_POST['edu_place'];
            $school_name = $_POST['school_name'];

//experience
            $exp_title = $_POST['exp_title'];
            $exp_country = $_POST['exp_country'];
            $exp_state = $_POST['exp_state'];
            $exp_period = $_POST['exp_period'];

//skills
            $sk_name = $_POST['sk_name'];
            $sk_place = $_POST['sk_place'];
            $sk_year = $_POST['sk_year'];
            
            $process=0;

            $search_cv = unirecords::get_applicantion_id_by_login_id($usernumber);
//            if (empty($names) && empty($date_birth) && empty($national_id) && empty($sex) && empty($father) && empty($mother) && empty($nationality) && empty($grade) && empty($grade_name) && empty($edu_place) && empty($school_name) && empty($search_cv) && empty($exp_title) && empty($exp_country) && empty($exp_state) && empty($exp_period) && empty($search_cv) && empty($sk_name) && empty($sk_place) && empty($sk_year) && empty($search_cv)) {
//                
//            } else {
                if (empty($search_cv)) { //if user hasn't a cv 
                    //save all the data (basics - cv -education - experience - skills)
                
                    if (!empty($names) && !empty($date_birth) && !empty($national_id) && !empty($sex) && !empty($father) && !empty($mother) && !empty($nationality)  && !empty($grade) && !empty($grade_name) && !empty($edu_place) && !empty($school_name)  && !empty($exp_title) && !empty($exp_country) && !empty($exp_state) && !empty($exp_period)   && !empty($sk_name) && !empty($sk_place) && !empty($sk_year) ) {
                    //if   the personal is filled

                        $save_personal_details = new_records::new_personal_identification($names, $date_birth, $residence, $national_id, $sex, $usernumber, $mother, $father, $nationality);
                        $last_application = unirecords::get_last_appliacant();
                        $new_cv = new_records::new_cv($last_application);
                       
                        $last_cv1 = unirecords::get_last_cv();
                        $save_education = new_records::new_education($grade, $grade_name, $edu_place, $school_name, $last_cv1);
                        
                        $last_cv2 = unirecords::get_last_cv();
                        $save_experiennce = new_records::new_experience($exp_title, $exp_country, $exp_state, $exp_period, $last_cv2);
                        
                        $last_cv3 = unirecords::get_last_cv();
                        $save_skills = new_records::new_skills($sk_name, $sk_place, $sk_year, $last_cv3); 
                        echo 'saved successfully';
                    }else{
                        echo'Personal details are mandatory';
                    }
  
                   
                    
                } else {
//save all the data (education - experience - skills)

                    echo'The user has cv';
                    //---------------education--------------------------------
                    if (!empty($grade) && !empty($grade_name) && !empty($edu_place) && !empty($school_name)) {//user has filled education form
                        echo'Education  set -';
                        $cv_by_user = unirecords::get_cv_id_in_cv($usernumber);
                        $save_education = new_records::new_education($grade, $grade_name, $edu_place, $school_name, $cv_by_user);

                        //$save_education=  new_records::new_education($grade, $grade_name, $edu_place, $school_name,$cv_id);
                    }
                    if (true) {//user has partially filled education
                    }
                    //---------------experience--------------------------------
                    if (!empty($exp_title) && !empty($exp_country) && !empty($exp_state) && !empty($exp_period)) {//user has filled all personal data
                    //save the personal data
                        $cv_by_user = unirecords::get_cv_id_in_cv($usernumber);
                        $save_experiennce = new_records::new_experience($exp_title, $exp_country, $exp_state, $exp_period, $cv_by_user);
                    }
                    if (true) {//if user pasrtially filled form
                    }
                    //----------------skills----------------------------------
                    if (!empty($sk_name) && !empty($sk_place) && !empty($sk_year)) {//user has filled education form
                        $cv_by_user = unirecords::get_cv_id_in_cv($usernumber);
                        $save_skills = new_records::new_skills($sk_name, $sk_place, $sk_year, $cv_by_user);
                    }
                    if (true) {//user has partially filled education
                    }
                }
            }
//        }
        
    } else if ($request == 'multi') {
        if ($_POST['method'] == 'profile_by_job') {
            $userid = $_POST['userid'];
            $_SESSION['userid']=$userid;
            $tot_jobs = unirecords::number_of_job_per_user($userid);
            if ($tot_jobs > 1) {
                //get jobs of the user
                $job_for_user = multi_records::get_my_jobs($userid);
//                echo 'jobs: ' . $job_for_user . '  user: ' . $userid;
                $profile = multi_records:: Profile_by_Many_job($userid);
                echo $profile ;
            } else if ($tot_jobs == 1) {
                $profile = multi_records:: Profile_by_job($userid);
                echo $profile ;
            }
        }
        if ($_POST['method'] == 'get_accepted_cv') {
            
        }
        if ($_POST['method'] == 'search_by_post_grade') {
            $post = $_POST['post'];
            $grade = $_POST['grade'];

            $cvs = multi_records::Many_Profile_by_post_grade($post, $grade);
            echo $cvs;
        }
    } else if ($request == 'uni') {

        if ($_POST['method'] == 'getjob_category_id') {
            $get_cat = unirecords::getjob_id($_POST['id']);
        }
        if ($_POST['method2'] = 'get_user_in_cv') {
            if (isset($_POST['usernumber'])) {
                $usernumber = $_POST['usernumber'];

                $search_cv = unirecords::get_applicantion_id_by_login_id($usernumber); //this is the app id
                $id = $_POST['id']; //this is the job title
                if (!empty($search_cv)) {
                    $jobid = unirecords::getjob_id($id);
                    
                    $save_job = new_records::new_user_job($jobid, $search_cv, 'pending');
                    echo'The application sent';
                } else {
                    echo 'You have to fill in the cv first ';
                }
            }
        }
        if ($_POST['method'] = 'get_if_applied_id') {
            $userid = $_POST['userid'];
            $response = unirecords::get_if_applied($userid);
            echo $response;
        }
        if ($_POST['method'] == 'get_applicants_by_job') {

            $application_id = $_POST['application_id'];
            $number = unirecords::applicants_by_job($application_id);
            echo 'applicants: ' . $number;
        }
    } else if ($request == 'update') {
        if ($_POST['method'] == 'republish_job') {
            $jobid = $_POST['jobid'];
            update::republish_job($jobid);
        }
        if ($_POST['method'] == 'removejob') {
            $jobid = $_POST['jobid'];
            update::Remove_job($jobid);
        }
        if ($_POST['method'] == 'confirm_application') {
            $jobid = $_POST['jobid'];
            $userid = $_POST['userid'];
            update::Confirm_Application($jobid, $userid);
            echo'Application accepted';
        }
        if ($_POST['method'] == 'confirm_application_many') {
            $jobid = $_POST['jobid'];

            $user_id = $_POST['user_id'];
            $user_found = unirecords::gey_if_applied_on_ajob($user_id, $jobid);
            if ($user_found != '') {//if the user has already registered on the same jb
                echo 'user has already registered he cantt register twice ' . $user_found;
            } else {
                //register by inserting in job user
                
                update::Confirm_Application($jobid,$user_id);
               
            }
        }
    } else if ($request == 'delete') {
        
    }
}

function user_has_cv($user) {
    $search_cv = unirecords::get_applicantion_id_by_login_id($user);
    if (!isset($search_cv)) {
        return true;
    } else {
        return false;
    }
}
