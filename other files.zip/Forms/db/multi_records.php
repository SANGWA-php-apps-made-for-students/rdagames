
<?php
if (!class_exists('dbconnection')) {
    require 'connection.php';
    $con = dbconnection::con_job();
}

class multi_records {

    function get_job_categories() {
        $con = dbconnection::con_job();
        // get the category id by name
        $query = "select * from job_category" or die(mysql_error());
        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo '<div       class="category_datalist">';
            echo '<div       class="id_div" style="display:none;">';
            echo $row['category_id'];
            echo'</div>';
            echo $row['name'];
            echo '</div>';
        }
    }

    function get_names_by_username_pass($username, $password) {

        $both;
        $con = dbconnection::con_users();
        $query = "select name , surname  from users where username='$username' and userpass='$password'" or die(mysql_error());
        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {

            $name = $row['name'];
            $surname = $row['surname'];
            $both = $name . '    ' . $surname;
        }
        return $both;
    }

    function get_all_jobs() {

        $con = dbconnection::con_job();
        // get the category id by name
        $query = "select * from job where job_status='available'" or die(mysql_error());
        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo '<div       class="datalist" style="min-height:130px;color:#000;">';
            echo'<div       class="id_div" style="text-transform:upper;color:#fff;background-color: #240635;">';
            echo $row['title'];
            echo '</div>';
            echo'<div class="job_desc">';
            echo $row['description'];
            echo'</div>';
            echo'<input type="submit" value="Apply" class="apply_button" />';
            echo '</div>';
        }
    }
function homepage_jobs(){
     $con = dbconnection::con_job();
        // get the category id by name
        $query = "select * from job where job_status='available'" or die(mysql_error());
        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo '<div       class="home_page_datalist" >';
            echo'<div       class="home_page_id_div" >';
            echo $row['title'];
            echo '</div>';
            echo'<div class="home_page_job_desc">';
            echo $row['description'];
            echo'</div>';
            echo'<input type="submit" value="Apply" class="apply_button" />';
            echo '</div>';
        }
}
    function get_all_jobs_for_admin() {
        $con = dbconnection::con_job();
        $n = 0;
        // get the category id by name
        $query = "select count(user_id) as 'Total', job.position_id, job.title,job.description, job_user.user_id  from job left join job_user on  job.position_id=job_user.job_id    where job.job_status='available'     group by job.title,job.position_id   " or die(mysql_error());
        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo '<div       class="admin_datalist"  ">';
            echo'<div       class="id_div" style="text-transform:upper;">';

            echo'<div  class="id_number" style="display:none;">';
            echo $row['position_id'];
            echo '</div>';
            echo $row['title'];
            echo '</div>';

            echo'<div class="admin_job_description">';
            echo $row['description'];
            echo'</div>';
            echo'<div  class="applicants">';

            echo $row['Total'];

            echo'</div>';
            echo'<div       class="remove_job">';
            echo'<div       class="remove_id" style="display:none">';
            echo $row['position_id'];
            echo'</div>';
            echo'<span class="applicants_remove" style="display:none;">';
            if (isset($row['user_id'])) {
                $n+=1;
                echo $n;
            }
            echo'</span>';
            echo'Remove';
            echo'</div>';
            echo '</div>';
        }
    }

    function get_all_unavailable_jobs() {
        $con = dbconnection::con_job();
        // get the category id by name
        $query = "select * from job where job_status='unavailable'" or die(mysql_error());
        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {

            echo '<div       class="unavailable_datalist"  ">';

            echo'<div       class="id_number" style="display:none;">';
            echo $row['position_id'];
            echo '</div>';

            echo'<div       class="admin_job_title">';
            echo $row['title'];
            echo '</div>';

            echo'<div       class="admin_job_description" >';
            echo $row['description'];
            echo '</div>';
            echo'<div       class="Publish_button">';
            echo' publish';
            echo'</div>';
            echo '</div>';
        }
    }

    function get_my_cv($userid) {
        $con = dbconnection::con_job();
        // get the category id by name
        $query = "SELECT applicant_basics.names, "
                . " applicant_basics.date_of_birth, "
                . " applicant_basics.residence, "
                . " applicant_basics.national_id, "
                . " applicant_basics.sex, "
                . " applicant_basics.mother_name, "
                . " applicant_basics.father_name, "
                . " applicant_basics.nationality, "
                . " skills.name, "
                . " skills.place, "
                . " skills.year, "
                . " experience.title, "
                . " experience.place_country,  "
                . " experience.state, "
                . " experience.period, "
                . " experience.cv_id, "
                . " education. grade, "
                . " education.grade_name, "
                . " education.place, "
                . " education.school_name from applicant_basics "
                . " join cv on applicant_basics.applicant_id=cv.applicant_id "
                . " join skills on cv.cv_id=skills.cv_id "
                . " join experience on experience.cv_id=cv.cv_id "
                . "join education on education.cv_id=cv.cv_id "
                . " where user_account='$userid '" or die(mysql_error());

        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo $row['names'];
            echo $row['date_of_birth'];
            echo $row['residence'];
            echo $row['national_id'];
            echo $row['sex'];
            echo $row['mother_name'];
            echo $row['father_name'];
            echo $row['nationality'];
        }
    }

    function get_All_cv() {
        $con = dbconnection::con_job();
        // get the category id by name
        $query = "SELECT distinct( applicant_basics.names), "
                . " applicant_basics.date_of_birth, "
                . " applicant_basics.residence, "
                . " applicant_basics.national_id, "
                . " applicant_basics.sex, "
                . " applicant_basics.user_account, "
                . " applicant_basics.mother_name, "
                . " applicant_basics.father_name, "
                . " applicant_basics.nationality, "
                . " skills.name, "
                . " skills.place, "
                . " skills.year, "
                . " experience.exp_title, "
                . " experience.place_country,  "
                . " experience.state, "
                . " experience.period, "
                . " experience.cv_id, "
                . " education. grade, "
                . " education.grade_name, "
                . " education.place, "
                . " education.school_name from applicant_basics "
                . " left join cv on applicant_basics.applicant_id=cv.applicant_id "
                . " left join skills on cv.cv_id=skills.cv_id "
                . " left join experience on experience.cv_id=cv.cv_id "
                . " left join education on education.cv_id=cv.cv_id "
                . " join job_user on job_user.user_id=applicant_basics.applicant_id group by applicant_basics.names" or die(mysql_error());

        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo'<div       class="admin_datalist">';

            echo'<span id="applicant_id" style="display:none;">';
            echo $row['user_account'];
            echo '</span>';

            echo'<table><tr><td>';
            echo $row['names'];
            echo'</td></tr>';

            echo'<tr><td>Date of birth:';
            echo $row['date_of_birth'];
            echo'</td></tr>';

            echo'<tr><td>Residence';
            echo $row['residence'];
            echo'</td></tr>';

            echo'<tr><td> national id';
            echo $row['national_id'];
            echo'</td></tr>';

            echo'<tr><td> Sex:';
            echo $row['sex'];
            echo'</td></tr>';

            echo'<tr><td>Mother name';
            echo $row['mother_name'];
            echo'</td></tr>';

            echo'<tr><td>Father name';
            echo $row['father_name'];
            echo'</td></tr>';

            echo'<tr><td>Nationality';
            echo $row['nationality'];
            echo'</td></tr>  </table>';

            echo'<div       class="view_button">View profile';
            echo'<span style="display:none;">';
            echo $row['user_account'];
            echo'</span>';
            echo'</div>';



            echo'</div>';
        }
    }

    function get_accepted_cv() {

        $con = dbconnection::con_job();
        // get the category id by name
        $query = "SELECT distinct( applicant_basics.names), "
                . " applicant_basics.date_of_birth, "
                . " applicant_basics.residence, "
                . " applicant_basics.national_id, "
                . " applicant_basics.sex, "
                . " applicant_basics.user_account, "
                . " applicant_basics.mother_name, "
                . " applicant_basics.father_name, "
                . " applicant_basics.nationality, "
                . " skills.name, "
                . " skills.place, "
                . " skills.year, "
                . " experience.exp_title, "
                . " experience.place_country,  "
                . " experience.state, "
                . " experience.period, "
                . " experience.cv_id, "
                . " education. grade, "
                . " education.grade_name, "
                . " education.place, "
                . " education.school_name from applicant_basics "
                . " left join cv on applicant_basics.applicant_id=cv.applicant_id "
                . " left join skills on cv.cv_id=skills.cv_id "
                . " left join experience on experience.cv_id=cv.cv_id "
                . " left join education on education.cv_id=cv.cv_id "
                . " join job_user on job_user.user_id=applicant_basics.applicant_id "
                . " where job_user.application_status='accepted' group by applicant_basics.names" or die(mysql_error());

        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo'<div class="admin_datalist">';

            echo'<span id="applicant_id" style="display:none;">';
            echo $row['user_account'];
            echo '</span>';

            echo'<table><tr><td>';
            echo $row['names'];
            echo'</td></tr>';

            echo'<tr><td>Date of birth:';
            echo $row['date_of_birth'];
            echo'</td></tr>';

            echo'<tr><td>Residence';
            echo $row['residence'];
            echo'</td></tr>';

            echo'<tr><td> national id';
            echo $row['national_id'];
            echo'</td></tr>';

            echo'<tr><td> Sex:';
            echo $row['sex'];
            echo'</td></tr>';

            echo'<tr><td>Mother name';
            echo $row['mother_name'];
            echo'</td></tr>';

            echo'<tr><td>Father name';
            echo $row['father_name'];
            echo'</td></tr>';

            echo'<tr><td>Nationality';
            echo $row['nationality'];
            echo'</td></tr>  </table>';

            echo'<div       class="view_button">View profile';
            echo'<span style="display:none;">';
            echo $row['user_account'];
            echo'</span>';
            echo'</div>';
            echo'</div>';
        }
    }

    function get_number_accepted_CV() {
        $con = dbconnection::con_job();
        // get the category id by name
        $query = "SELECT count( applicant_basics.applicant_id) as Total from applicant_basics "
                . " join job_user on job_user.user_id=applicant_basics.applicant_id "
                . " where job_user.application_status='accepted' group by applicant_basics.applicant_id" or die(mysql_error());

        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo'<div class="Total_applied">';

            echo'<span id="applicant_id" style="display:none;">';
            echo $row['Total'];
            echo '</span>';
        }
    }

    function Profile_by_job($userid) {

        $con = dbconnection::con_job();
        // get the category id by name
        $query = "SELECT distinct("
                . " applicant_basics.applicant_id ),"
                . " applicant_basics.names, "
                . " applicant_basics.date_of_birth, "
                . " applicant_basics.residence, "
                . " applicant_basics.national_id, "
                . " applicant_basics.sex, "
                . " applicant_basics.user_account, "
                . " applicant_basics.mother_name, "
                . " applicant_basics.father_name, "
                . " applicant_basics.nationality, "
                . " skills.name, "
                . " skills.place, "
                . " skills.year, "
                . " experience.exp_title, "
                . " experience.place_country,  "
                . " experience.state, "
                . " experience.period, "
                . " experience.cv_id, "
                . " education.grade, "
                . " education.grade_name, "
                . " education.place, "
                . " education.school_name , "
                . " job.title   ,"
                . " job.position_id from applicant_basics"
                . " left join cv on applicant_basics.applicant_id=cv.applicant_id "
                . " left join skills on cv.cv_id=skills.cv_id "
                . " left join experience on experience.cv_id=cv.cv_id "
                . " left join education on education.cv_id=cv.cv_id "
                . " join job_user on job_user.user_id=applicant_basics.applicant_id "
                . " join job on job.position_id=job_user.job_id where user_account='$userid' group by applicant_basics.names " or die(mysql_error());

        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            ?>

            <div class="Profile_paper">
                <div class="accept_button_holder">
                    <!--<script src="../../js/jquery-1.9.1.min.js" type="text/javascript"></script>-->
                    <!--<script src="../GD/admin_scripts.js" type="text/javascript"></script>-->
                    <div class="application_jobTitle">POSITION : <?php echo $row['title']; ?>   </div>

                    <div class="Accept_single_cv"> Accept  <p style="display: none;"><?php echo $row['exp_title']; ?></p>
                        <span style="display: none;"><?php echo $row['applicant_id']; ?></span>
                        <div style="display: none;" ><?php echo $row['position_id']; ?></div>

                    </div>
                </div>

                <ul style="list-style:none;">
                    <?php echo' <div       class="cv_titles" style="margin-bottom: 20px;">Personal details</div>'; ?>
                    <li>       <div class="profile_data" ><div   class="designation"> Names:</div><span class="profiledata_item">  <?php echo $row['names']; ?></span> </div>  </li>
                    <li><div class="profile_data" ><div       class="designation" >Date of birth:</div>   <?php echo $row['date_of_birth']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Residence:</div>   <?php echo $row['residence']; ?></div> </li>
                    <li><div class="profile_data" ><div       class="designation">National id:</div>   <?php echo $row['national_id']; ?></div></li>
                    <li><div class="profile_data" > <div       class="designation">Sex:</div>  <?php echo $row['sex']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">User:</div>   <?php echo $row['user_account']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Mother names:</div>   <?php echo $row['mother_name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Father names:</div>   <?php echo $row['father_name']; ?></div></li>
                    <li><div class="profile_data" style="margin-bottom: 20px;"><div       class="designation">Nationality:</div>   <?php echo $row['nationality']; ?> </div></li>
                    <?php
                    echo' <div       class="cv_titles" >Skills</div>  <br/><br/>';
                    ?>
                    <li><div class="profile_data" ><div       class="designation">Skill title</div> <?php echo $row['name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Place:</div> <?php echo $row['place']; ?></div> </li>
                    <li><div class="profile_data" style="margin-bottom: 20px;" ><div       class="designation">Year:</div> <?php echo $row['year']; ?></div></li>
                    <?php
                    echo'<div       class="cv_titles">Experience</div><br/><br/>';
                    ?>

                    <li><div class="profile_data" ><div       class="designation">Title:</div> <?php echo $row['exp_title']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Country:</div> <?php echo $row['place_country']; ?></div> </li>
                    <li><div class="profile_data" ><div       class="designation">State:</div> <?php echo $row['state']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Period:</div> <?php echo $row['period']; ?> </div></li>
                    <li><div class="profile_data"style="margin-bottom: 20px;" ><div       class="designation">Cv:</div> <?php echo $row['cv_id']; ?></div></li>
                    <?php
                    echo'<div        class="cv_titles">Education</div> <br/><br/>';
                    ?>
                    <li><div class="profile_data" ><div        class="designation">Grade:</div>  <?php echo $row['grade']; ?> </div></li>
                    <li><div class="profile_data" ><div       class="designation">Grade name:</div> <?php echo $row['grade_name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Place: </div> <?php echo $row['place']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">School / College / unversity name:</div> <?php echo $row['school_name']; ?></div></li>

                </ul>
            </div>

            <?php
        }
    }

    function Profile_by_Many_job($userid) {//cv for someone who applied on many jobs
        $con = dbconnection::con_job();
        // get the category id by name
        $query = "SELECT distinct("
                . " applicant_basics.applicant_id ),"
                . " applicant_basics.names, "
                . " applicant_basics.date_of_birth, "
                . " applicant_basics.residence, "
                . " applicant_basics.national_id, "
                . " applicant_basics.sex, "
                . " applicant_basics.user_account, "
                . " applicant_basics.mother_name, "
                . " applicant_basics.father_name, "
                . " applicant_basics.nationality, "
                . " skills.name, "
                . " skills.place, "
                . " skills.year, "
                . " experience.exp_title, "
                . " experience.place_country,  "
                . " experience.state, "
                . " experience.period, "
                . " experience.cv_id, "
                . " education.grade, "
                . " education.grade_name, "
                . " education.place, "
                . " education.school_name , "
                . " job.title   ,"
                . " job.position_id from applicant_basics"
                . " left join cv on applicant_basics.applicant_id=cv.applicant_id "
                . " left join skills on cv.cv_id=skills.cv_id "
                . " left join experience on experience.cv_id=cv.cv_id "
                . " left join education on education.cv_id=cv.cv_id "
                . " join job_user on job_user.user_id=applicant_basics.applicant_id "
                . " join job on job.position_id=job_user.job_id where user_account='$userid' group by applicant_basics.names " or die(mysql_error());

        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            ?>

            <div class="Profile_paper">
                <div class="accept_button_holder">
<!--                    <script src="../../js/jquery-1.9.1.min.js" type="text/javascript"></script>
                    <script src="../GD/admin_scripts.js" type="text/javascript"></script>-->
                    <div class="application_jobTitle">POSITION :<?php echo $row['title']; ?> </div>

                </div>

                <ul style="list-style:none;">
                    <?php echo' <div       class="cv_titles" style="margin-bottom: 20px;">Personal details</div>'; ?>
                    <li><div class="profile_data" ><div   class="designation"> Names:</div><span class="profiledata_item">  <?php echo $row['names']; ?></span> </div>  </li>
                    <li><div class="profile_data" ><div class="designation" >Date of birth:</div>   <?php echo $row['date_of_birth']; ?></div></li>
                    <li><div class="profile_data" ><div class="designation">Residence:</div>   <?php echo $row['residence']; ?></div> </li>
                    <li><div class="profile_data" ><div class="designation">National id:</div>   <?php echo $row['national_id']; ?></div></li>
                    <li><div class="profile_data" ><div class="designation">Sex:</div>  <?php echo $row['sex']; ?></div></li>
                    <li><div class="profile_data" ><div class="designation">User:</div>   <?php echo $row['user_account']; ?></div></li>
                    <li><div class="profile_data" ><div class="designation">Mother names:</div>   <?php echo $row['mother_name']; ?></div></li>
                    <li><div class="profile_data" ><div class="designation">Father names:</div>   <?php echo $row['father_name']; ?></div></li>
                    <li><div class="profile_data" style="margin-bottom: 20px;"><div       class="designation">Nationality:</div>   <?php echo $row['nationality']; ?> </div></li>
                    <?php
                    echo' <div       class="cv_titles" >Skills</div>  <br/><br/>';
                    ?>
                    <li><div class="profile_data" ><div       class="designation">Skill title</div> <?php echo $row['name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Place:</div> <?php echo $row['place']; ?></div> </li>
                    <li><div class="profile_data" style="margin-bottom: 20px;" ><div       class="designation">Year:</div> <?php echo $row['year']; ?></div></li>
                    <?php
                    echo'<div       class="cv_titles">Experience</div><br/><br/>';
                    ?>

                    <li><div class="profile_data" ><div       class="designation">Title:</div> <?php echo $row['exp_title']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Country:</div> <?php echo $row['place_country']; ?></div> </li>
                    <li><div class="profile_data" ><div       class="designation">State:</div> <?php echo $row['state']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Period:</div> <?php echo $row['period']; ?> </div></li>
                    <li><div class="profile_data"style="margin-bottom: 20px;" ><div       class="designation">Cv:</div> <?php echo $row['cv_id']; ?></div></li>
                    <?php
                    echo'<div        class="cv_titles">Education</div> <br/><br/>';
                    ?>
                    <li><div class="profile_data" ><div        class="designation">Grade:</div>  <?php echo $row['grade']; ?> </div></li>
                    <li><div class="profile_data" ><div       class="designation">Grade name:</div> <?php echo $row['grade_name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Place: </div> <?php echo $row['place']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">School / College / unversity name:</div> <?php echo $row['school_name']; ?></div></li>

                </ul>
            </div>

            <?php
        }
    }

    function Many_Profile_by_post_grade($post, $grade) {

        $con = dbconnection::con_job();
        // get the category id by name
        $query = "SELECT "
                . " applicant_basics.applicant_id ,"
                . " applicant_basics.names, "
                . " applicant_basics.date_of_birth, "
                . " applicant_basics.residence, "
                . " applicant_basics.national_id, "
                . " applicant_basics.sex, "
                . " applicant_basics.user_account, "
                . " applicant_basics.mother_name, "
                . " applicant_basics.father_name, "
                . " applicant_basics.nationality, "
                . " skills.name, "
                . " skills.place, "
                . " skills.year, "
                . " experience.exp_title, "
                . " experience.place_country,  "
                . " experience.state, "
                . " experience.period, "
                . " experience.cv_id, "
                . " education.grade, "
                . " education.grade_name, "
                . " education.place, "
                . " education.school_name , "
                . " job.title   ,"
                . " job.position_id from applicant_basics "
                . " left join cv on applicant_basics.applicant_id=cv.applicant_id "
                . " left join skills on cv.cv_id=skills.cv_id "
                . " left join experience on experience.cv_id=cv.cv_id "
                . " left join education on education.cv_id=cv.cv_id "
                . " left join job_user on job_user.user_id=applicant_basics.applicant_id "
                . " left join job on job.position_id=job_user.job_id where job.title='$post' and education.grade='$grade' group by applicant_basics.names " or die(mysql_error());

        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            ?>

            <div class="Profile_paper">
                <div class="accept_button_holder">
<!--                    <script src="../../js/jquery-1.9.1.min.js" type="text/javascript"></script>
                    <script src="../GD/admin_scripts.js" type="text/javascript"></script>-->
                    <div class="application_jobTitle">POSITION :<?php echo $row['title']; ?>   </div>

                    <div class="Accept_single_cv"> Accept  <p style="display: none;"><?php echo $row['exp_title']; ?></p>
                        <span style="display: none;"><?php echo $row['applicant_id']; ?></span>
                        <div style="display: none;" ><?php echo $row['position_id']; ?></div>

                    </div>
                </div>

                <ul style="list-style:none;">
                    <?php echo' <div       class="cv_titles" style="margin-bottom: 20px;">Personal details</div>'; ?>
                    <li>       <div class="profile_data" ><div   class="designation"> Names:</div><span class="profiledata_item">  <?php echo $row['names']; ?></span> </div>  </li>
                    <li><div class="profile_data" ><div       class="designation" >Date of birth:</div>   <?php echo $row['date_of_birth']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Residence:</div>   <?php echo $row['residence']; ?></div> </li>
                    <li><div class="profile_data" ><div       class="designation">National id:</div>   <?php echo $row['national_id']; ?></div></li>
                    <li><div class="profile_data" > <div       class="designation">Sex:</div>  <?php echo $row['sex']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">User:</div>   <?php echo $row['user_account']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Mother names:</div>   <?php echo $row['mother_name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Father names:</div>   <?php echo $row['father_name']; ?></div></li>
                    <li><div class="profile_data" style="margin-bottom: 20px;"><div       class="designation">Nationality:</div>   <?php echo $row['nationality']; ?> </div></li>
                    <?php
                    echo' <div       class="cv_titles" >Skills</div>  <br/><br/>';
                    ?>
                    <li><div class="profile_data" ><div       class="designation">Skill title</div> <?php echo $row['name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Place:</div> <?php echo $row['place']; ?></div> </li>
                    <li><div class="profile_data" style="margin-bottom: 20px;" ><div       class="designation">Year:</div> <?php echo $row['year']; ?></div></li>
                    <?php
                    echo'<div       class="cv_titles">Experience</div><br/><br/>';
                    ?>

                    <li><div class="profile_data" ><div       class="designation">Title:</div> <?php echo $row['exp_title']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Country:</div> <?php echo $row['place_country']; ?></div> </li>
                    <li><div class="profile_data" ><div       class="designation">State:</div> <?php echo $row['state']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Period:</div> <?php echo $row['period']; ?> </div></li>
                    <li><div class="profile_data"style="margin-bottom: 20px;" ><div       class="designation">Cv:</div> <?php echo $row['cv_id']; ?></div></li>
                    <?php
                    echo'<div        class="cv_titles">Education</div> <br/><br/>';
                    ?>
                    <li><div class="profile_data" ><div        class="designation">Grade:</div>  <?php echo $row['grade']; ?> </div></li>
                    <li><div class="profile_data" ><div       class="designation">Grade name:</div> <?php echo $row['grade_name']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">Place: </div> <?php echo $row['place']; ?></div></li>
                    <li><div class="profile_data" ><div       class="designation">School / College / unversity name:</div> <?php echo $row['school_name']; ?></div></li>

                </ul>
            </div>

            <?php
        }
    }

    function get_my_jobs($userid) {
        $con = dbconnection::con_job();
        $query = "select position_id, job.title, job_user.user_id from job join job_user on job.position_id=job_user.job_id join applicant_basics on applicant_basics.applicant_id=job_user.user_id where applicant_basics.user_account='$userid' and application_status ='pending'" or die(mysql_error());
        $res1 = mysql_query($query)or die(mysql_error());
        while ($row = mysql_fetch_array($res1)) {
            echo'<div class="job_item">';

            echo'<div class="job_title_data_item">';
            echo'<span>';
            echo'<div class="id">';
            echo $row['position_id'];
            echo'</div>';
            echo'   <p>';
            echo $row['user_id'];
            echo '</p>';

            echo '</span>';

            echo $row['title'];
            echo '</div>';

            echo'</div>';
        }
    }

}
