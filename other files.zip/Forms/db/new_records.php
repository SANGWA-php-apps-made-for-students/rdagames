<?php
if (!class_exists('dbconnection')) {
    require 'connection.php';
    $con = dbconnection::con_job();
}

class new_records {
    
    function new_personal_identification($names,$date_ofbirth,$residence,$residence_city,$national_id,$sex,$user,$mother,$father,$nationality,$language){
         $query = "insert into applicant_basics values(null,'$names','$date_ofbirth','$residence','$residence_city','$national_id','$sex','$user','$mother','$father','$nationality','$language')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully' .$date_ofbirth ;
        
    }
    function newjob_post($title, $categoryid, $jobstatus, $description) {
        $query = "insert into job values(null,'$title','$categoryid','available','$description')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function new_education($grade, $grade_name, $place, $schoolname,$cv_id) {
        $query = "insert into education values(null,'$grade','$grade_name','$place','$schoolname','$cv_id')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function new_skills($name, $place, $year, $cv_id) {
        $query = "insert into skills values(null,'$name','$place','$year','$cv_id')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }

    function new_experience($title, $country, $state, $period,$cv_id) {
        $query = "insert into experience values(null,'$title','$country','$state','$period','$cv_id')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }
    function new_user_job($job_id, $userid, $status) {
        $query = "insert into job_user values('$job_id','$userid','$status')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        //echo 'data saved succefully';
    }
      function new_cv($applicant_id) {
        $query = "insert into cv values(null,'$applicant_id')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'data saved succefully';
    }
     function newtest($userid){
         $query = "insert into userid values(null,'$userid')" or die(mysql_error());
        mysql_query($query)or die(mysql_error());
        echo 'test saved succefully'  ;
        
    }
    
    
    
    
    
    
    
    

}
