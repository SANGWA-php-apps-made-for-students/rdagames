<?php
class dbconnection {

    function con_users() {
        $con = mysql_connect('localhost', 'sangwa', 'A.manigu125') or die(mysql_error());
        mysql_select_db('usersmanagement')or die(mysql_error());
    }

    function con_visits() {
        $con = mysql_connect('localhost', 'sangwa', 'A.manigu125') or die(mysql_error());
        mysql_select_db('rdavisitstrack')or die(mysql_error());
    }

    function con_job(){
         $con = mysql_connect('localhost', 'sangwa', 'A.manigu125') or die(mysql_error());
        mysql_select_db('rdajobapp')or die(mysql_error());
    }
}
