<!DOCTYPE html>
<html>
    <head>
        <title>News</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
        <link rel="icon" href="images/rg_icon.png">
    </head>
    <body>
        <form method="post" action="news.php">
            <div class="box">

                <div class="contents" >
                 <?php include './menuToall.php'; ?>
                    <p>
                    <h2 class="big_titles" style="color:#fff;">News</h2>
                    </p>
                    <div style="float: right; width: 30%;background-color: #fff; padding: 10px; border: 2px solid #fff;border-top-left-radius:20px;">
                        <h2 class="big_titles">latest news</h2>
                        <div style="padding: 10px;">
                            <h2><u>RWanda Games is now eligible</u></h2>
                            <p class="paragraph" style="font-weight:400;">
                                As RWANDA GAMES is aimed to be Sports betting the Strongest Sports betting Company 
                                of the nation, it  has been eligible for starting betting activities since 29/03/2016.
                         </p>
                        </div>

                    </div>
                    <div style="float: left; width:55%;background-color: #fff; padding: 10px; border: 2px solid #fff; ">
                        <h2 class="big_titles">ForthComing events</h2>
                        <h2>More branches are going to be open soon</h2>
                        <div class="paragraph" style="font-weight:400;">
                            For extensibility and outreach of Rwanda Games betting acivities to the population,
                            we are now about to open new branches.
                            The first ones will be established in Kigali City 
                            and thus others in other provinces.


                        </div>
                    </div>

                </div>
                <?php include('footer.php'); ?> 
            </div>
        </form>
        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('a').click(function () {
                    var link = $(this).attr('href');
                    $.post('tracks/newtrack.php', {link: link}, function (data) {
                        // $(".display").text('returned data is:  '+data);
                        $('.contents').load(link);

                    });
                })
            });
        </script>
    </body>
</html>