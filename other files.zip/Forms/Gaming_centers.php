<!DOCTYPE html>
<html>
    <head>
        <title>Gaming centers</title>
        <meta name="viewport" content="initial-scale=1.0">
        <meta charset="utf-8">
        <style>
            html, body {

            }
            #map {
                height: 700px;
                width: 900px;
            }
        </style>
        <link href="../webstyles/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>	
        <div class="box" style="overflow-x: hidden;">
            
            <div class="contents"> 
                <?php include './menuToall.php'; ?>
                <p>Find the nearest betting shop around you</p>
                <div id="map">

                </div>
                <div style="float: right; width: 20%; 
                     min-height: 100px;margin-top: 30px;
                     border: 1px solid #0000ff;padding: 0px 4px 4px 4px; font-size: 12px; 
                     background-color: #7b7bb7; ">
                    <h4 class="GoodLookingTitles" >Current gaming centers</h4>

                    <div style="background-color: #fff; padding:  8px;">
                        We are currently still establishing new gaming centers and they are going to be 
                        available to you soon.
                    </div>
                </div>
            </div>
            <?php include '../Forms/footer.php'; ?>
        
        <script>
            var map;
            function initMap() {
                map = new google.maps.Map(document.getElementById('map'), {
                    center: {lat: -1.90, lng: 29.944},
                    zoom: 9
                });
            }
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoeRs_jgCnSaeCBT2QHFB2Jxr3sZskkLk&callback=initMap"
        async defer></script>
    </body>
</html>