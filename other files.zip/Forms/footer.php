<!DOCTYPE html>
<html>
    <head>
        <title></title>
    </head>
    <body>
        <div class="footer">

            <div class="footer_p">
                <p>Mission</p>
                <div style=" font-size: 12px; padding: 10px;">
                    To provide world class betting Entertainment hub; to offer limitless entertainment, passion and fun to citizens
                    through gambling in Rwanda and the region”
                </div>
            </div>
            <div class="footer_p">
                <p>Vision</p>
                <div style=" font-size: 12px; padding: 10px;">
                    To be a leading betting, gambling firm in Rwanda
                </div>
            </div>
            <div class="footer_p" style="border: none;">
                <p>Cooporate</p>
                <div style=" font-size: 12px; padding: 10px;">
                    Join us and expand your dreams that leads to prosperous and true future
                </div>
            </div>

            <div class="copyrights">
                copyright &copy 20<?php echo date('y'); ?></div>
        </div>
    </body>
</html>