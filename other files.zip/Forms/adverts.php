<?php
session_start();
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Jobs</title>
        <link href="../webstyles/styles.css" rel="stylesheet" type="text/css"/>
        <link href="GD/admin_styles.css" rel="stylesheet" type="text/css"/>
        <style type="text/css">

        </style>
    </head>
    <body class="body_of_advert">

        <form action="adverts.php" method="post">

            <div class="all_preface">

            </div>
            <div class="advert_dialog">
                <span class="advert_dialog_title">Message</span>
                <div class="advert_dialogbody">

                    <div class="fc_bk">
                        <span id="Logged_in">
                            <p id="logged_in_link"></p>
                        </span>
                        <span id="not_logged_id">
                            <p id="not_logged_in_link"></p>
                        </span>
                    </div>
                </div>
                <input type="submit" value="Save" style="margin-right: 5px;" class="yellow_buttons"/>
                <input type="submit" id="cancel_advert_dialog" value="Cancel" style="margin-right: 5px;" class="yellow_buttons"/>

            </div>
            <div class="box" style="overflow-x: hidden">
                <?php
                include 'menuToall.php';
                ?>
                <div class="contents" style="overflow-x: hidden; background-color: #fff;">
                    <?php
                    include '../Forms/db/multi_records.php';
                    $jobs = multi_records::homepage_jobs();
                    ?>
                </div>
                <?php
                include '../Forms/footer.php';
                ?>
            </div>
            <script src="../js/jquery-1.9.1.min.js" type="text/javascript"></script>
            <script type="text/javascript">
                var counter = 0,
                        logged_in = 0;
                $(document).ready(function () {
                    cancel_dialog();
                    apply_cicked();
                    CheckLoginStatus();
                    //                every_sec_refresh();
                });
                function every_sec_refresh() {
                    setTimeout(function () {
                        counter += 1;
                        refreshStatus();
                        if (logged_in = 0) {
                            $("#logged_in_link").html('Please login to proceed' + counter);
                        } else {
                            $("#logged_in_link").html('Continue ' + counter);
                        }

                        every_sec_refresh();
                    }, 1000);
                }

                function apply_cicked() {
                    $('.apply_button').click(function (e) {
                        if (logged_in == 1) {
                            window.location = "http://localhost/rdagamesN/Forms/pub_users/pub_users_homepage.php";

                        } else {
                            e.preventDefault();
                            FB.login(
                                    function (response) {
                                        console.log(response);
                                        refreshStatus();
                                    },
                                    {
                                        scope: 'public_profile,email',
                                        auth_type: 'rerequest'
                                    }
                            );
                        }

                        //                    $('.all_preface').show();
                        //                    $('.advert_dialog').show(300);
                    });
                }
                function cancel_dialog() {
                    $('#cancel_advert_dialog').click(function () {
                        $('.all_preface').hide();
                        $('.advert_dialog').hide(300);
                    });
                }
                refreshStatus = function ()
                {
                    FB.getLoginStatus(function (st) {
                        var info = $('#login-info').html();
                        if (st.status == "connected")
                        {
                            getInfo();
                            $(".login-btn").attr("disabled", "disabled");
                            logged_in = 1;
                            //                         window.location = "http://www.rwandagames.co.rw/pub_users/pub_users_homepage.php";
                        } else {
                            $("#logged_in_link").html('Please login to proceed');
                            logged_in = 0;
                        }

                    });
                };
                getInfo = function ()
                {
                    FB.api("/me", function (data) {
                        console.log(data);
                        $("#logged_in_link").html(data.name);
                        $('.id-info').html(data.id);
                        var names = ('#Facebook_login > span').html(data.name);
                        //insert session
                        window.location = "http://localhost/rdagamesN/Forms/pub_users/pub_users_homepage.php";

                    });
                };
                function CheckLoginStatus() {
                    $.ajaxSetup({cache: true});
                    $.getScript('//connect.facebook.net/en_US/sdk.js', function () {
                        FB.init({
                            appId: '1606031006354656',
                            cookie: true,
                            version: 'v2.6' // or v2.1, v2.2, v2.3, ...
                        });
                        refreshStatus();
                        $("#login-info-face").click(function (e) {
                            e.preventDefault();
                            FB.login(
                                    function (response) {
                                        console.log(response);
                                        refreshStatus();
                                    },
                                    {
                                        scope: 'public_profile,email',
                                        auth_type: 'rerequest'
                                    }
                            );
                        });
                    });
                }

            </script>
        </form>
    </body>
</html>
<?php

function apply() {
    if (isset($_SESSION['userid'])) {//here the session is set we let him apply
    } else {
        if (true) {
            
        }
    }
}
