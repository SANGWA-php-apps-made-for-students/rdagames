<!DOCTYPE html>
<html>
    <head>
        <title>About us</title>
        <link rel="stylesheet" type="text/css" href="../webstyles/styles.css">
        <link rel="icon" href="images/rg_icon.png">
    </head>
    <body>
        <form method="post" action="aboutus.php">

            <div class="box">
                <div class="contents" >
                    <?php include './menuToall.php'; ?>
                    <h1 class="big_titles" style="margin-top:30px"> Who we are</h1>
                    <div class="paragraph" style="font-weight: 400; background-color:#fff; padding: 10px; border: 1px solid #39004d;">
                        <h4 >Rwanda games</h4>
                        Is a licensed company that is aimed to operate in betting-related  activities for numerous different games.
                        Thus people will entertain through betting activities.
                    </div>	
                    <h1 class="big_titles" style="margin-top:30px"> What we do</h1>
                    <div class="paragraph" style="font-weight: 400; background-color:#fff; padding: 10px; border: 1px solid #39004d;">
                        <h4 >About RWANDA GAMES</h4>
                        Online sport bets - Live bets like never before – no 
                        matter whether you are a fan of football, tennis, basketball or 
                        ice hockey or whether you are interested in particular in the German 
                        Bundesliga, Spanish Primera Division, English Premier League, 
                        Italian Serie A, or the 2016 football European Championship,
                        you will always be in on the action with Tipico bets.
                        We offer above-average betting odds, a clear live score and 
                        results service for everything from football to volleyball,
                        a comprehensive live bet offer and much more. 
                    </div>
                    <h1 class="big_titles" style="margin-top:30px"> Location </h1>
                    <div class="paragraph" style="font-weight: 400; background-color:#fff; padding: 10px; border: 1px solid #39004d;">
                        <h4>
                            You can find us with these adresses:	</h4><ul class="address">

                            <li>
                                <u>
                                    <a href="mpeaceplazagallery.php">
                                        M.PEACE PLAZA, 7<sup>th</sup> floor</a></u></li>
                            <li>P.O Box: 325 Kigali</li>
                            <li>Mob: +250 788 500 586</li>
                            <li>Email: info@rwandagames.co.rw</li>

                        </ul>
                    </div>
                </div>


                <?php include('footer.php'); ?> 
            </div>

        </form>
        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="application/javascript" src="http://jsonip.appspot.com/?callback=getip"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('a').click(function () {
                    var link = $(this).attr('href');
                    $.post('tracks/newtrack.php', {link: link}, function (data) {
                        // $(".display").text('returned data is:  '+data);
                        $('.contents').load(link);

                    });

                    $.getJSON("http://jsonip.com/?callback=?", function (data) {
                        console.log(data);
                        var track_location = data.ip;
                        //send the location
                        $.post('tracks/newtrack.php', {track_location: track_location}, function (data) {
                            // $(".display").text('returned data is:  '+data);

                        });
                    });
                });
            });


        </script>
    </body>
</html>