<div class="menu">
    <a href="../../../index.php">Home</a>
    <a href="../../Aboutus.php">About us</a>
    <a href="../../news.php">News</a>
    <a href="../../Gaming_centers.php">Gaming centers</a>
    <a href="../../carrier.php">Careers</a>
    <a href="../../Partners.php">Partners</a>
    <a href="../../Contactus.php">Contact us</a>
    
   
</div>
