<div class="slide_box">
    <div class="slide_pics" id="pic1">
        <div class="pic_desc">first</div>
    </div>
      
        <div class="slide_pics" id="pic2"></div>
        <div class="slide_pics" id="pic3"></div>
        <div class="slide_pics" id="pic4"></div>
        <div class="slide_pics" id="pic5"></div>
        <div class="slide_pics" id="pic6"></div>
        <div class="slide_pics" id="pic7"></div>
        <div class="slide_pics" id="pic8"></div>
      <div class="slide_pics" id="pic9">
           
      
      </div>
     
</div>
      
