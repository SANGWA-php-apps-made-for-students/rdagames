  <div class="dark_bg">
           
        </div>
        
        <div class="slide parts">
            <?php
           
            include './slideitems/pictures.php';
            ?>

        </div>
