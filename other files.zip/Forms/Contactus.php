<!DOCTYPE html>
<html>
    <head>
        <title>Contacts</title>
        <link rel="stylesheet" type="text/css" href="../webstyles/styles.css">
        <link rel="icon" href="images/rg_icon.png">
    </head>
    <body>
        <form method="post" action="Contactus.php">
            <div class="box">

                <div class="contents">
                  <?php include './menuToall.php';?>

                    <div class="big_titles" style=" margin-top: 10px; width: 60%;">You can contact us with this address</div>
                    <div id="contactus_sidepane" style="min-width:30%; float: left; background-color: #c7c3e3; padding: 10px; border: 1px solid #fff;
                         margin-top:50px;">
                        <h2 class="GoodLookingTitles">Address:</h2>	

                        <ul>
                            <li><span id="info_link" class="bullet_image">Email: info@rwandagames.co.rw</span></li>
                            <span id="info_expanding_pane">

                            </span>
                            <li><span class="bullet_image">Telephone:0788500586</span></li>
                            <li><span class="bullet_image">Place(Main head office): M.Peace Plaza, 7th floor</span></li>
                            <li><span class="bullet_image">P.O.Box325</span></li>


                        </ul>
                    </div>


                </div><?php include('footer.php'); ?> 
            </div>

        </form>
        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('a').click(function () {
                    var link = $(this).attr('href');
                    $.post('tracks/newtrack.php', {link: link}, function (data) {
                        // $(".display").text('returned data is:  '+data);
                        $('.contents').load(link);

                    });
                })
            });
        </script>
    </body>
</html>