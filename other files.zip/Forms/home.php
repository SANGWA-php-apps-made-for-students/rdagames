

<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link href="../webstyles/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="header">
            <div class="logo">

            </div>	
            <div class="title">
                <span class="title_p1">RWANDA</span>
                <span class="title_p2">GAMES</span>
            </div>
            <div class="moving_text"><marquee>Gaming world</marquee></div>
            <div class="login_register">
                <a href="accounts/newuser.php" class="login_register">Register</a>
                <a href="accounts/login.php" class="login_register">login</a>
            </div>
        </div>

        <div class="menu">
            <a id="home_link" href="index.php" class="home_menu" >
                Home</a>
            <a href="Aboutus.php">About us</a>
            <a href="news.php">News</a>
            <a href="Gaming_centers.php">Gaming Centres</a>
            <a href="carrier.php">Career</a>
            <a href="Partners.php">Partners</a>
            <a href="Contactus.php">Contact us</a>

        </div><div class="two_pictures">
            <a href="mpeaceplazagallery.php">
                <div class="pic1" name="pic1"></div></a>
            <div class="pic2"></div>
        </div>
        <div class="slide_box">
            <div class="slide_box">
                <div id="slide_pic1" class="Events">
                    <span id="test_paragraph"></span>
                    <div class="sliding_text" style="overflow: auto;">

                    </div>
                </div>
                <div id="slide_pic2" class="Events">
                    <span id="test_paragraph">Earn on every bet</span>
                    <div class="sliding_text"></div>

                </div>  

                <div id="slide_pic3" class="Events">
                    <span id="test_paragraph">It is all about riches and fun</span>
                    <div class="sliding_text"></div>

                </div> 


            </div>
            
            
           
        </div>
        

        <!--        <div class="types_sports">
                    <p class="big_titles " style="color:white;">Types of sports</p>
                    <h2>You can bet on:</h2>
        
                    <div class="ball_icon">
                        <div id="football_icon">
        
                        </div>
                        <div class="ball_icon_description" style="overflow: auto;">
                            Bet on every football match
        
                        </div></div>
                    <div class="ball_icon">
                        <div id="volleyball_icon">
        
                        </div>
                        <div class="ball_icon_description">Get connected with Volley ball channels</div>
                    </div>
        
                    <div class="ball_icon">		
                        <div id="basketball_icon">
        
                        </div>
                        <div class="ball_icon_description">Know real-time matches</div>
                    </div>
                    <div class="ball_icon">
                        <div id="horses_icon">
        
                        </div>
                        <div class="ball_icon_description">Dont miss out interesting horse races</div>
                    </div>
                    <div style="width: inherit; padding: 6px; float: right">
        
                    </div>
                </div>-->


        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" type="tracks/track.js"></script>
        <script type="text/javascript" src="scripts.js"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('a').click(function () {
                    var link = $(this).attr('href');
                    $.post('tracks/newtrack.php', {link: link}, function (data) {
                        // $(".display").text('returned data is:  '+data);
                        $('.contents').load(link);

                    });
                })
            });
        </script>
    </body>
</html>