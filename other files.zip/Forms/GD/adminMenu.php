<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>

        <div class="admin_menu" style="border: 1px solid green">
            <a id="newdoc" href="NewDoc.php"><span class="space_icon"><img src="../images/file.png" align="center"></span>Add new document</a><br/>
            <a id="sharedoc" href="Sharedoc.php"><span class="space_icon"><img src="../images/sahre.png" align="center"></span>Share document</a><br/>
            <a id="removedoc" href="RemoveDoc.php"><span class="space_icon"><img src="../images/remove.png" align="center"></span>Remove document</a><br/>
            <a id="newuser" href="newuser_role.php"><span class="space_icon"><img src="../images/remove.png" align="center"></span>Add new user category</a><br/>

            <a id="" href="NewSpecial_User.php"><span class="space_icon"><img src="../images/add.png" align="center"></span>Add new staff</a>

        </div>
        <div class="admin_contents" style="float: left;">

        </div>
        <div id="display" style="margin-top:20px; float: left">

        </div>
        <script type="text/javascript" src="../js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="scripts.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
            // $('#newdoc').click(function(){

            // 	var newdoc_page=$('#newdoc').attr('href');

            // 	$.post('../tracks/newtrack.php',{newdoc_page: newdoc_page},function(data){
            // 		$("#display").text('returned data is:  '+data);
            //  });
            // 	 return false;
            });
//            });
        </script>
    </body>
</html>