<?php
if (isset($_POST['link'])) {
    $link = $_POST['link'];
    echo $link;
} else {
    
}
?>



<html>
    <head>
        <title>
            tracks 
        </title>
        <link href="tracks.css" rel="stylesheet" type="text/css"/>
        <link rel="icon"  href="../images/rg_icon.png">
    </head>
    <body>
        <form action="HomePages_tracls.php" method="post">
            <div class="admin__sub_menu" >
                <a id="documents_link" href="#">Detailed </a>
                <a id="leaves_link" href="#">Summarized </a>
             </div>
 <div class="data_table" cellpadding="10">
     <div class="small_font">  Detailed report</div>
                <table  >
                    <tr style="background-color: #300c40; color: #fff;">

                        <td>id</td>
                        <td>device</td>
                        <td>IP</td>
                        <td>date</td>
                        <td>location</td>
                        <td>Registered</td>
                        <td>Page</td>
                        <td>Times</td>
                        <td>User</td>
                    </tr>
                    <?php
                    include '../../db/connection.php';
                    $conn= connection::con_visits();
                    
                                        
                    $query = "SELECT * from visitor_track";
                    $res = mysql_query($query) or die(mysql_error());
                    while ($row = mysql_fetch_array($res)) {
                        ?>
                        <tr> 
                            <td> <?php echo $row['trackid']; ?></td>

                            <td> <?php echo $row['track_device']; ?></td>
                            <td> <?php echo $row['track_ip']; ?></td>
                            <td> <?php echo $row['track_date']; ?></td>
                            <td> <?php echo $row['track_location']; ?></td>
                            <td> <?php echo $row['track_registered']; ?></td>
                            <td> <?php echo $row['page']; ?></td>
                            <td> <?php echo $row['Times']; ?></td>
                            <td> <?php echo $row['track_user']; ?></td>

                        </tr>
                        <?php }
                    ?></table><?php
                    ?>
            </div>




        </form>
        <script src="../js/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="track.js" type="text/javascript"></script>

    </body>
</head>
</html>

