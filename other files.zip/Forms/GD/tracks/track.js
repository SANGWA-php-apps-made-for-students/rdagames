$(document).ready(function() {

 
	NewTrack();
	$('#home_link').hover(function(){
		alert('hello');
	});
});

function NewTrack(){
	$('#home_link').hover(function(){
		alert('hello');
	});
}