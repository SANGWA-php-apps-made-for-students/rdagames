<?php
if (isset($_POST['link'])) {
	$link=$_POST['link'];
	echo  $link;
	//connect to db

	//save in db;

//search if the link exixts by same day


		$year=date("Y");
      	$month=date("m");
      	$day=date("d");
      	    $con=mysql_connect('localhost','visits_trackuser','visits_track@user!123') or die(mysql_error());
	 		mysql_select_db('visits_track')or die(mysql_error());

		    $query1="SELECT * FROM visitor_track where year(track_date)='$year' and month(track_date)='$month' and day(track_date)='$day' and page='$link'";
		    $res1=mysql_query($query1) or die(mysql_error());
		    if($row=mysql_fetch_array($res1)){
					    	//Get the number of times
					    	 $query2="SELECT Times from  visitor_track where year(track_date)='$year' and month(track_date)='$month' and day(track_date)='$day' and page='$link'";
					         $res2=mysql_query($query2) or die(mysql_error());
							 if ($row=mysql_fetch_array($res2)) {
							 	echo("The times are found");
									//if the times are found
								     $times_visited=$row['Times'];
								     $add=$times_visited+1;
								     //update
								     $query3="UPDATE  visitor_track set Times='$add' where year(track_date)='$year' and month(track_date)='$month' and day(track_date)='$day' and page='$link'";
								     mysql_query($query3)or die(mysql_error());
									 mysql_close($con);
							}
			}else{
			        $track_device=$mac;
					$track_ip="";
					$track_date="";
					$track_location=$_POST['track_location'];
					$track_registered="no";
					$track_page=$newdoc_page;
					$times=1;
					$track_user="";
					$con=mysql_connect('localhost','visits_trackuser','visits_track@user!123') or die(mysql_error());
					mysql_select_db('visits_track')or die(mysql_error());
					$user_category= $row['categoryid'];
					$query="insert into visitor_track values(null,'$track_device','$track_ip',null,'$track_location','$track_registered','$link','$times','$track_user')" or die(mysql_error());
					mysql_query($query)or die(mysql_error());
					mysql_close($con);
		    	}



	 
								 
} else if (condition) {
	 
}

?>;