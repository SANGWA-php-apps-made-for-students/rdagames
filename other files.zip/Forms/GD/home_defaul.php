
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../styles.css">
</head>
<body>




<div id="left_any_menu" style="float: left; min-width: 20%; padding: 10px; min-height: 300px;">
							<div class="admin_menu">
								<a id="newdoc" href="NewDoc.php"><span class="space_icon"><img src="../images/file.png" align="center"></span>Add new document</a><br/>
								<a id="sharedoc" href="Sharedoc.php"><span class="space_icon"><img src="../images/sahre.png" align="center"></span>Share document</a><br/>
								<a id="removedoc" href="RemoveDoc.php"><span class="space_icon"><img src="../images/remove.png" align="center"></span>Remove document</a><br/>
								
		 					</div>
</div>
		 					<div class="admin_contents">
				 
				 </div>
<div  style="float:right; width:10%;border-left:1px solid #00334d;
						min-height: 200px;padding-left:5px;">
					<a href="../accounts/logout.php"><span class="space_icon"><img src="../images/logout.png" align="center"></span>Logout</a>
				</div>

<script type="text/javascript" src="../js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="admin_scripts.js"></script>
</body>
</html>