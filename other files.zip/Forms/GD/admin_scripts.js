
var jobcat_id = 0;

var count_disappear = 0;

//database inter variables
var request = '';
var director_count = 0;
var dialog_counter = 0;
$(document).ready(function () {
    Document_clicked();
    Leave_clicked();
    Staff_clicked();
    job_clicked();
    visits_clicked();

    newpost_clicked();
    selectapplication_clicked();

    reject_application_clicked();

    apply_clicked();
    hide_msg_after_10_sec();
    get_job_cat_id();
    savejob_post();

    get_id_by_applicant();

    available_jobs();
    job_list();
    Applicant_by_job_hovered();

    applicants_per_jobClicked();
    applicants_by_job();
    republish();
    jobReport_clicked();

    ViewProfile_clicked();
    Accept_profile();

    job_title_hovered();
    job_title_leave();

    job_title_clicked();
    job_rep_link();
    Accepted_cv();
    search_next_btn();
    search_btn1();
    HideDialog();
    Get_IP();
    show_default_gd_info();
    show_director_info();
    close_report_viewer();
    close_appl_report_viewer();
    
    selected_reportitem();
});

/*main menu*/
function Document_clicked() {
    $('#documents_link').click(function () {
//        var path = 'docs/NewDoc.php';
//        $('.admin_contents').load(path);
        $('.contents').hide();
        $('.side_menu').hide();

        $('#doc_side_menu').show();
        $('#doc_content1').fadeIn(200);
        slide_sub_menu_titles();
        return false;
    });
}
function Leave_clicked() {
    $('#leaves_link').click(function () {
//        var path = 'docs/Sharedoc.php';
//        $('.admin_contents').load(path);
        $('.contents').hide();
        $('.side_menu').hide();

        $('#leave_side_bar').show();
        $('#leave_content1').fadeIn(200);
        slide_sub_menu_titles();
        return false;
    });
}
function Staff_clicked() {
    $('#staff_link').click(function () {
//        var path = 'staff/list_staf.php';
//        $('.admin_contents').load(path);
        $('.contents').hide();
        $('.side_menu').hide();
        $('#staff_side_bar').show();
        $('#staff_content1').fadeIn(200);
        slide_sub_menu_titles();
        return false;
    });
}
function job_clicked() {
    $('#jobs_link').click(function () {
//        var path = 'job/job_home_page.php';
//        $('.admin_contents').load(path);

        $('.contents').hide();
        $('.side_menu').hide();
        $('#job_side_bar').show();
        $('#job_content1').fadeIn(200);
        slide_sub_menu_titles();

        return false;
    });
}
function visits_clicked() {
    $('#visits_link').click(function () {
//        var path = 'tracks/HomePage_tracks.php';
//        $('.admin_contents').load(path);
        $('.contents').hide();
        $('.side_menu').hide();

        $('#webvisits_content1').show();
        $('#webvisits_side_Bar').fadeIn(200);
        slide_sub_menu_titles();
        return false;
    });
}
function slide_sub_menu_titles() {
    $('.sub_menu_title').animate({marginLeft: '50'}, 100);
    $('.sub_menu_title').delay(400).animate({marginLeft: '+=180'}, 300);
}



/*job sub menu*/
function newpost_clicked() {
    $('#admin_newpost').click(function () {
//        var path = 'job/newjob.php';
//        $('.all_sub_contents').load(path);
        $('.contents').hide();

        $('#job_content2').show();
        $('.job_content').fadeOut(100);

        return false;
    });
}
function job_list() {
    $('#job_list_link').click(function () {

//        admin_request = 'admin';

        $('.contents').hide();
        $('#job_content6').fadeIn(200);

        return false;
    });
}
function selectapplication_clicked() {
    $('#job_select_application').click(function () {
//        var path = 'staff/list_staf.php';
//        $('.all_sub_contents').load(path);

        $('.contents').hide();
        $('#job_content4').fadeIn(200);
        return false;
    });
}

function jobReport_clicked() {
    $('#Job_reportst_link').click(function () {
//        var path = 'job/remove_job_post.php';
//        $('.all_sub_contents').load(path);
        $('.contents').hide();
        $('#job_content7').fadeIn(200);
        return false;
    });
}
function reject_application_clicked() {
    $('#admin_reject_application').click(function () {
//        var path = 'job/jobReport.php';
//        $('.all_sub_contents').load(path);
        $('.job_content').fadeOut(100);
        $('#job_content4').fadeIn(200);
        return false;
    });
}


//End submenu

//start sub of sub menu of job list
function job_list_sub() {
    $('#remove_jobs').click(function () {
//        var path = 'job/UnavailableJobs.php';
//        $('.job_sub_sub_contents').load(path);
        alert('the list shown');
        return false;
    });
}
function available_jobs() {
    $('#available_jobs').click(function () {
        var path = 'job/AvailableJobs.php';
        $('.job_sub_sub_contents').load(path);
        return false;
    });
}

//End of sub of sub menu of job
function HideDialog() {
    $('#dialog_cancel').click(function () {
        $('.All_overlay').fadeOut(100);
        $('.admin_dialog').animate({marginTop: '-=600'}, 1000).hide();
        return false;
    });
}

function Showdialog(txt) {
    $('.All_overlay').fadeIn(100);
    $('.admin_dialog').html(txt);
    $('.admin_dialog').show().animate({marginTop: '100'});
}
function show_hide_dialog(txt) {
    dialog_counter = 0;
    Showdialog(txt);
    showdialog_3sec();//starts to count for 3 seconds
}
function showdialog_3sec() {
    setTimeout(function () {
        dialog_counter += 1;
        if (dialog_counter == 3) {
            dialog_counter = 0;
            HideDialog();
        }
        showdialog_3sec();
    }, 1000);
}
function Get_IP() {
    $.getJSON("http://jsonip.com/?callback=?", function (data) {
        console.log(data);
        // alert(data.ip);
    });

}
function get_id_by_applicant() {
    $('#view_button').click(function () {
        alert('the id ');
    });
}
function ViewProfile_clicked() {
    $('.view_button').click(function () {
        var userid = '';
        userid = $(this).children('span:first').html();
        var path = 'job/Profile_by_apllication.php',
                method = 'profile_by_job',
                request = 'multi';
        $('#job_section2 >span').html(userid);

        $.post('../db/handler.php', {userid: userid, request: request, method: method}, function (data) {
            $('.all_sub_contents').html(data);
            $('.job_content_section').hide();
            $('.report_results').show();
            $('#applicantsclose_button').fadeIn(500);
            $('.report_results').show().html(data);
        });

    });
}
function Accept_profile() {//to accept the profile
    $('.Accept_single_cv').click(function () {
        var userid = $(this).children('span:first').html(),
                jobid = $(this).children('div:first').html();
        var request = 'update',
                method = 'confirm_application';
        $.post('../db/handler.php', {userid: userid, jobid: jobid, request: request, method: method}, function (data) {
            alert(data);
        });
    });
}
function Accepted_cv() {//to view accepted CVs
    $('#acceptedcv').click(function () {
        var request = 'multi',
                method = 'get_accepted_cv',
                path = 'job/AcceptedCv.php';
        $('.job_sub_sub_contents').load(path);


        return false;
    });
}
function get_job_cat_id() {
    $('.datalist, .category_datalist').click(function () {
        var id = $(this).children("div:first").text();
        //   get all div normal color
        $('.datalist, .category_datalist').css('background-color', '#8ab3aa');
        //    change only which you hace clicked
        $(this).css('background-color', '#1a0033');
        //    Indicate the id by giving a white color
        $('.id_div, .category_datalist').css('color', '#ffffff');
        $(this).children("div:first").css('color', '#ffffff');
        $('.alert').html('').css('padding', '0');
        jobcat_id = id;
    });

}
function savejob_post() {
    $('#send_job').click(function () {
        var title = $('#job_title').val(),
                id = jobcat_id,
                title = $('#job_title').val(),
                description = $('#job_desc').val(),
                job_status = $('#job_status').val(),
                request = 'new',
                method = 'newjob_post';

        if (jobcat_id == '') {
            $('.alert').html('You have to choose the direction').css('background-color', 'red').css('color', 'white').css('padding', '7');
            return false;
        } else if (title == '' || description == '') {
            $('.alert').html('You have to enter all the fields').css('padding', '7').addClass('red_alert');
            return false;
        } else {
            $.post('../db/handler.php', {method: method, request: request, title: title, id: id, job_status: job_status, description: description}, function (data) {
                $('.alert').html(data).addClass('green_alert');
                return false;
            });
            return false;
        }


    });

}
function apply_clicked() {
    $('.datalist').click(function () {
        var id = $(this).children('div:first').text(), //this is title of the job which is supposed to be unique
                method = 'getjob_category_id',
                method2 = 'get_user_in_cv',
                usernumber = $('#usernumber').val(),
                request = 'uni';

        var userid = $('#userid').text();
        var date
        $.post('../db/handler.php', {request: request, method: method, id: id, usernumber: usernumber, userid: userid, method2: method2}, function (data) {
            $('.msg_warn').fadeIn(400).html(data).addClass('msg_warn_padding');
        });
        return false;
    });
}

function job_title_hovered() {
    //this is when hovered on a job title for someone who applied on many jobs
    $('.job_title_data_item').hover(function () {
        $(this).children('span:first').stop();
//                $(this).children('span:first').animate({height:'+100'});;
    });
}
function job_title_leave() {
    //this is when hovered on a job title for someone who applied on many jobs
    $('.job_title_data_item').mouseleave(function () {
//        $(this).children('span:first').slideUp(400);
    });
}
function job_title_clicked() {
    $('.job_title_data_item span').click(function () {
        var jobid = $(this).find('div.id').html();
        var user_id = $(this).children('p:first').html();
        var request = 'update',
                method = 'confirm_application_many';

        $.post('../db/handler.php', {method: method, request: request, jobid: jobid, user_id: user_id}, function (data) {
            alert(data);
        });
    });
    return false;
}
function job_rep_link() {
    $('#job_report_link').click(function () {
        $('.tabitem').hide();
        $('#rep_alljobs').show(200);
        return false;
    });
}
function search_next_btn() {
    $('.filter_option_combo').change(function(){ 
        var filter_text = $('.filter_option_combo option:selected').text();
        if (filter_text == 'Post  and grade') {
            $('.rep_data_part').hide();
            $('#optional_data1').show();

        } else if (filter_text == 'Post, grade and years') {
            $('.rep_data_part').hide();
            $('#optional_data2').show();
        } else if (filter_text == 'Post, grade, years and experience') {
            $('.rep_data_part').hide();
            $('#optional_data3').show();
        } else if (filter_text == 'Post, grade and sex') {
            $('.rep_data_part').hide();
            $('#optional_data4').show();
        } else if (filter_text == 'Post, grade and nationality') {
            $('.rep_data_part').hide();
            $('#optional_data5').show();
        } else if (filter_text == 'Post, grade, nationality and experience') {
            $('.rep_data_part').hide();
            $('#optional_data6').show();
        } else if (filter_text == 'Post, grade, nationality and sex') {
            $('.rep_data_part').hide();
            $('#optional_data7').show();
        } else if (filter_text == 'Post, grade, nationality, experience and sex') {
            $('.rep_data_part').hide();
            $('#optional_data8').show();
        }
        return false;
    });
}
function selected_reportitem(){//the item selected int eh combobox
//   $('.filter_option_combo').change(function(){ 
//       var item = $('.filter_option_combo option:selected').text();
//        if (item=='Post  and grade') {
//            alert('first item');
//        }else{
//            alert('uknown');
//        }
//    });
    
}
function search_btn1() {
    $('#search_btn1').click(function () {
        var post = $('#rep_post').val();
        var grade = $('#rep_grade').val(),
                request = 'multi',
                method = 'search_by_post_grade';
        $.post('../db/handler.php', {request: request, post: post, grade: grade, method: method}, function (data) {
            $('.report_results').html(data);
        });
        $('.report_results').show();
        $('#close_button').fadeIn(500);
        $('.contents').hide();
        return false;
    });
}
function close_report_viewer() {
    $('#close_button').click(function () {
        $('.report_results').fadeOut(500);
        $('.contents').hide();

        $(this).hide();
        $('#job_content7').show();
    });
}
function close_appl_report_viewer() {
    $('#applicantsclose_button').click(function () {
        $('.report_results').fadeOut(500);
        $('.contents').hide();
        $(this).hide();

        $('#job_content4').show();
    });
}
function get_tot_jobs() {

}
function get_tot_applicants() {

}
function get_tot_staff() {

}
function show_default_gd_info() {
    $('#gd_defaultcontents').show();
//    alert('gd');
}
function show_director_info() {
    setTimeout(function () {
        director_count += 1;

        if (director_count == 2) {
            $('#dg_docs').show(300);

        }
        if (director_count == 4) {
            $('#gd_leave').show(300);
        }
        if (director_count == 6) {
            $('#gd_staff').show(300);
        }
        if (director_count == 8) {
            $('#gd_visits').show(300);
        }
        if (director_count == 10) {
            $('#gd_job').show(300);
        }

        show_director_info();
    }, 2000);
}

function hide_msg_after_10_sec() {
    setTimeout(function () {
        count_disappear += 1;
        if (count_disappear == 10) {
            count_disappear = 0;
            $('.msg_warn').hide();
        }
        hide_msg_after_10_sec();
    }, 1000);
}

function applicants_per_jobClicked() {
    $('#applicants').click(function () {
        var application_id = $('.id_number').html();

//        alert(application_id);
//          $('#applicants').html();
    });
}
function applicants_by_job() {
    var application_id = $('.id_number').html();
    var method = 'get_applicants_by_job', request = 'uni';
    $.post('../db/handler.php', {method: method, request: request, application_id: application_id}, function (data) {

    });
}

function republish() {
    $('.unavailable_datalist').click(function () {
        var jobid = $(this).children('div:first').html();

        var method = 'republish_job',
                request = 'update';
        $.post('../db/handler.php', {method: method, request: request, jobid: jobid}, function (data) {

        });
        $(this).fadeOut(1500);
    });
}
function Applicant_by_job_hovered() {
    $('.applicants').mouseover(function () {
        if ($(this).html() > 0) {
            $(this).css('cursor', 'pointer');

        }

    });
}
function joRe() {
    $('.remove_job').click(function () {

        var jobid = $(this).children('div:first').html(),
                request = 'update',
                method = 'removejob';

        var id_span = $(this).children('span:first').html();
        if (id_span != '') {
            $.post('../db/handler.php', {method: method, request: request, jobid: jobid}, function (data) {
                alert(data);
//                var path = 'job/availableJobs.php';
//                $('.job_sub_sub_contents').load(path);
//                jobid='';
            });
        }

    });

}