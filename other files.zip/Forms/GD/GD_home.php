<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['session_set'])) {
    header("location:../index.php");
    echo "redirect to index";
} else {
    
}

$year = date("Y");
$month = date("m");
$day = date("d");
include '../db/connection.php';
$db = new dbconnection();
$con = $db->con_visits();

$query1 = "SELECT * FROM visitor_track where year(track_date)='$year' and month(track_date)='$month' and day(track_date)='$day'";
$res1 = mysql_query($query1) or die(mysql_error());
if ($row = mysql_fetch_array($res1)) {
    
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            General director  dashboard
        </title>

        <link href="../../webstyles/styles.css" rel="stylesheet" type="text/css"/>
        <link href="admin_styles.css" rel="stylesheet" type="text/css"/>
        <link rel="icon"  href="../images/rg_icon.png">
    </head>
    <body >
        <form action="Partners.php" method="post" > 
            <div class="All_overlay">

            </div>
            <div class="admin_dialog">
                Do you want to save
                <a href="#" id="dialog_cancel">Cancel</a>
            </div>

            <?php
//         side bars
            include './job/menus/admin_hoz_menu.php';
            include './job/contents/content1_admin_default_content.php';

            include './job/side_bars/docs_side_bar.php';
            include './job/contents/docs_content_1.php';

            include './job/side_bars/leave_side_bar.php';
            include './job/contents/leave_content1.php';

            include './job/side_bars/staff_side_bar.php';
            include './job/contents/staff_content_1.php';

            include './job/side_bars/webVisits_side_bar.php';
            include './job/contents/webVisits_content1.php';

            include './job/side_bars/jobs_sideb_bar.php';
            include './job/menus/job_menu_1.php';
            include './job/contents/job_content_1.php';
            include './job/contents/job_content_2_new_job.php';
            include './job/contents/job_content_6_job_list.php';

            include './job/menus/job_menu2_applications.php';
            include './job/contents/job_content_4_applications_list.php';

            include './job/contents/job_content_7_jobReport.php';
            ?>

        </form>
        <script type="text/javascript" src="../../js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="admin_scripts.js"></script>

    </body>
</html>