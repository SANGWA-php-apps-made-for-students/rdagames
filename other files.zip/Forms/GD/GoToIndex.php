<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="styles.css">
        <link href="admin_styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        
        <div  class="admi_header">
            <div class="admin_logo">

            </div>	
            <div class="admin_title">
                <span class="title_p1">RWANDA</span>
                <span class="title_p2">GAMES</span>
            </div>
            
            
        </div>
       

    </body>
</html>
