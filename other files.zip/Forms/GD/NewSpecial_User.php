<?php 
if(!isset($_SESSION)) {
	session_start();
// 	if(!isset($_SESSION['admin'])){
//   	header("location:../index.php");
// }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		New user
	</title>
	<link rel="stylesheet" type="text/css" href="../styles.css">
	<link rel="icon"  href="../images/rg_icon.png">
</head>
<body>
<form action="NewSpecial_User.php" method="post">
	
		
			<?php

				if (isset($_POST['send'])) {
		             //save in the reservation
				    $username=$_POST['email'];
					$password=$_POST['password'];
					$telephone=$_POST['telephone'];
					$category_id=$_POST['category_id'];
						// get the category id by name
				    $con=mysql_connect('localhost','usersuser','users@user!123') or die(mysql_error());
				    mysql_select_db('usersmanagement')or die(mysql_error());

				    $query="select categoryid from users_category where category_name='$category_id'" or die(mysql_error());
				    $res1=mysql_query($query)or die(mysql_error());
					    if ($row=mysql_fetch_array($res1)) {
					    	    $user_category= $row['categoryid'];
					    	      $query="insert into users values(null,'$username','$password','$telephone','$user_category')" or die(mysql_error());
								  mysql_query($query)or die(mysql_error());
								  mysql_close($con);
								  echo "Data saved successfully";
					    }else{
					    	echo "The user category has not been found $category_id";
					    }
				
			}
			?>
			 
			 
				  <div class="pane">
					<div class="pane_title">Sign Up For Account</div>
					<div class="pane_content">
						<p class="no_left_margin">Name:
						<input type="text" placeholder="Enter Name" name="name"></p>	
						<p class="no_left_margin">Surname:	
						<input type="text" placeholder="Enter Surname" name="surname"></p>
						<p class="no_left_margin">Email:	
						<input type="text" placeholder="Enter email" name="email"></p>
						 
						<p class="no_left_margin">	Passwrod:
						<input type="password" placeholder="Enter password" name="password"></p>
						<p class="no_left_margin">	Category/role:
						
						<select name="category_id">
							<option>
								<?php
											   	$con=mysql_connect('localhost','usersuser','users@user!123') or die(mysql_error('unable to login to db'));
											    	mysql_select_db('usersmanagement')or die(mysql_error('unable to get the db'));
												         $query="SELECT category_name from  users_category";
											       $res=mysql_query($query) or die(mysql_error());
											       while($row=mysql_fetch_array($res)){
							 							echo"

								 							<option value=".$row['category_name'].">".$row['category_name']."</option>"
								 							 ;
													}
												?>
							</option>
						</select>

						<input type="submit" value="Add" name="send">
					</div>
			</div> 
				<div style="float: left; width: 100%;overflow:hidden; padding: 10px; 
					min-height: 90px;
				   margin-top: 30px;  ">
				  <table border="1" cellpadding="4">
				  		<tr style="background-color: #9933ff; color: #fff;">
				  			<td>user number</td>
				  			<td>username</td>
				  			<td>password</td>
				  			<td>Telephone</td>
				  			<td>Category</td>
				    	</tr>
									<?php
											   	$con=mysql_connect('localhost','usersuser','users@user!123') or die(mysql_error('unable to login to db'));
											    	mysql_select_db('usersmanagement')or die(mysql_error('unable to get the db'));
												         $query="SELECT * from users";
											       $res=mysql_query($query) or die(mysql_error());
											       while($row=mysql_fetch_array($res)){
									?>
							 			<tr>
							 			 
												<td><?php echo $row['userid']; ?></td>
												<td><?php echo $row['username']; ?></td>
												<td><?php echo $row['userpass']; ?></td>
												<td><?php echo $row['telephone']; ?></td>
												<td><?php echo $row['category_id']; ?></td>
										 
										</tr>
											<?php							 							 
													}

									?>
						</table>

													
									
				</div>

 
</form>
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="scripts.js"></script>
</body>
</html>