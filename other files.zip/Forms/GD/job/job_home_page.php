<?php
require '../db/uni_records.php';

?>


<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>

        <link href="../../../webstyles/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
       
        <div id="job_content2"  class="job_content">
            <?php
            include 'admin_job_list.php';
            ?>
        </div>
        <div id="job_content3"  class="job_content">
        
            
            
            
            
            <div id="job_section2" class="job_content_section">
                <span></span>
                <?php
               //echo multi_records::Profile_by_job($_SESSION['userid']);
                include '../job/Profile_by_apllication.php';
 ?>
            </div>

        </div>
        <div id="job_content4"  class="job_content">
           <?php include 'job/jobReport.php';  ?>
        </div>
        <div id="job_content5"  class="job_content">
            job item 5
        </div>
        <div id="job_content6"  class="job_content">
            job item 6
        </div>
<!--        <script src="../../../js/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="admin_scripts.js" type="text/javascript"></script>-->

    </body>
</html>
