<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        require '../../db/multi_records.php';
        echo multi_records::get_accepted_cv();
        ?>
        <script src="../../pub_users/pubscripts.js" type="text/javascript"></script>
        <script src="admin_scripts.js" type="text/javascript"></script>
    </body>
</html>
