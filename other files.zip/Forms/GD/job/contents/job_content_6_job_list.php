<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="contents" id="job_content6">
        <?php
         require_once '../db/multi_records.php';
        $jobs = multi_records::get_all_jobs_for_admin();
        ?></div>
    </body>
</html>
