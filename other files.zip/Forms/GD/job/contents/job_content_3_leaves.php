<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="contents" id="m_menu_leaves">
                                <div id="sub_menu1_2" class="sub_menu1">
                                    sub menu 2
                                </div>
                                <div id="sub_menu1_content_2" class="sub_menu1_content">
                                    <span id="sub_menu_title_2" class="sub_menu_title">
                                        Leaves management
                                    </span>
                                </div>
                            </div> 
    </body>
</html>
