<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body> <div id="applicantsclose_button">

        </div>
        <div class="applicantsreport_results">

        </div>
        <div class="contents" id="job_content4">
          <?php
              require_once '../db/multi_records.php';
        $All_cv=  multi_records::get_All_cv();
        ?></div>
    </body>
</html>
