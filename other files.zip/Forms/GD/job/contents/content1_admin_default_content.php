<?php
require '../db/uni_records.php';

?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
         <div class="contents" id="gd_defaultcontents">
            job management
            <span id="sub_menu_title_1" class="sub_menu_title ">
                job management
...
            </span>
             <div class="job_homepage_news" id="job_home_number_jobs">
            <?php
            echo             'There are :  ' . unirecords::get_tot_applicants() . ' applicants ';
            ?>
        </div>
        <div class="job_homepage_news" id="job_home_number_applicants">
            <?php 
            echo ', ' . unirecords::get_tot_jobs() . ' jobs'; ?>
        </div>
        <div class="job_homepage_news" id="gd_staff">
            <?php
            echo ' and ' . unirecords::get_tot_Staff() . ' people approved as staff'; ?>
        </div>
        
            
        </div>
        
    </body>
</html>
