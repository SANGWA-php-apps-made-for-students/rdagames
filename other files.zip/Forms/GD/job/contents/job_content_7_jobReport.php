<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body> 
        <div id="close_button">

        </div>
        <div class="report_results">

        </div>
        <div class="contents" id="job_content7">
            <div class="tab_titles">
                <a id="job_report_link" class="tabtitle" href="#">Jobs</a>
                <a id="applicant_report_link" class="tabtitle" href="#">applicants</a>
                <a class="tabtitle" href="#">Jobs</a>
                <a class="tabtitle" href="#">Jobs</a>
                <a class="tabtitle" href="#">Jobs</a>
            </div> 
            <table  class="wide_table">
                <tr>
                    <td>Select option:</td> 
                    <td> <select class="filter_option_combo">
                            <option>Post  and grade</option>
                            <option>Post, grade and years</option>
                            <option>Post, grade, years and experience</option>
                            <option>Post, grade and sex</option>
                            <option>Post, grade and nationality</option>
                            <option>Post, grade, nationality and experience</option>
                            <option>Post, grade, nationality and sex</option>
                            <option>Post, grade, nationality, experience and sex</option>
                        </select>
                    </td>

                    <td>
                        <input type="submit" value="Go" class="next_button"/>

                    </td>
                    <td>

                    </td>
                </tr>
                <tr class="search_row">
                    <td></td>

                    <td>
                        <div class="data_search_text_input">
                            <div class="rep_data_part"  id="optional_data1">
                                <table>
                                    <tr>
                                        <td>Post</td>
                                        <td> <input type="text" id="rep_post" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade</td>
                                        <td>
                                            <input type="text" id="rep_grade" size="10"  class="small_textinput" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td>
                                            <input type="submit" size="10" class="search_report_button" id="search_btn1"   value="search" />
                                        </td>
                                    </tr>

                                </table>


                            </div>
                            <div class="rep_data_part"  id="optional_data2">
                                <table>
                                    <tr>
                                        <td>Post:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Years:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>

                                </table>


                            </div>
                            <div class="rep_data_part"  id="optional_data3">
                                <table>
                                    <tr>
                                        <td>Post:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Years:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Experience:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                </table>

                            </div>
                            <div class="rep_data_part"  id="optional_data4">
                                <table>
                                    <tr>
                                        <td>Post:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Sex:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>

                                </table>
                            </div>
                            <div class="rep_data_part"  id="optional_data5">
                                <table>
                                    <tr>
                                        <td>Post:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Years:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Nationality:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="rep_data_part"  id="optional_data6">
                                <table>
                                    <tr>
                                        <td>Post:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Years:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Nationality:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Experience:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="rep_data_part"  id="optional_data7">
                                <table>
                                    <tr>
                                        <td>Post:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Years:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Nationality:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>

                                    <tr>
                                        <td>Sex:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="rep_data_part"  id="optional_data8">
                                <table>
                                    <tr>
                                        <td>Post:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Grade:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Years:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Nationality:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Experience:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                    <tr>
                                        <td>Sex:</td>
                                        <td><input type="text" size="10"  class="small_textinput" /></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </td>
                    <td colspan="2">

                    </td>
                </tr>
            </table>    

        </div>
    </body>
</html>
