<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="contents" id="job_content2">
            <table class="data_input_table">

            <tbody>
                <tr>
                    <td>Title</td>
                    <td><input class="small_input_text" type="text" id="job_title" value="" size="30"/></td>
                </tr>
                <tr>
                    <td>Category</td>
                    <td>
                        <?php
                        include '../db/multi_records.php';
                        $list = multi_records::get_job_categories();
                        ?>
                    </td>

                </tr>
                <tr>
                    <td></td>
                    <td><input class="small_input_text" type="hidden" id="job_status" value="pending" size="30"/></td>
                </tr>
                <tr>
            <div id="id_getter"></div>
            <td>Description</td>
            <td>
                <textarea name="" rows="10" cols="74" id="job_desc" class="textarea">
                </textarea>

            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input class="yellow_buttons" type="submit" id="send_job" value="Post" size="30"/>
            </td>
        </tr>

    </tbody>
</table>
        </div>
    </body>
</html>
