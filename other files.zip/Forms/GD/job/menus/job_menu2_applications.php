<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       <div class="filter_controls">
            filter

            <div class="icon_parent_holder">
                <div class="icon_holder">
                    <div class="icon_image" id="icon_removed"></div>
                    <div class="icon_text">
                        <a id="acceptedcv" href="#">Accepted cv</a>

                    </div>
                </div>
            </div>
         </div>
    </body>
</html>
