   
<div class="admin__hoz_menu" >
    <a id="documents_link" href="#">Documents </a>
    <a id="leaves_link" href="#">Leave </a>
    <a id="staff_link" href="#">Staff</a>
    <a id="visits_link" href="#">Web visits</a>
    <a id="jobs_link" href="#">Jobs</a>

    <a id="admin_logout_link" href="../../accounts/logout.php">Logout</a>
</div>