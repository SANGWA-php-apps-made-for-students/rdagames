<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="filter_controls">
        

            <div class="icon_parent_holder">
                <div class="icon_holder">
                    <div class="icon_image" id="icon_removed"></div>
                    <div class="icon_text">
                        <a id="remove_jobs" href="#">Removed</a>

                    </div>
                </div>
            </div>
            <div class="icon_parent_holder">
                <div class="icon_holder" >
                    <div class="icon_image"id="icon_empty"></div>
                    <div class="icon_text">
                        <a id="available_jobs" href="#">Available</a>

                    </div>
                </div>
            </div>
            <div class="icon_parent_holder">
                <div class="icon_holder">
                    <div class="icon_image" id="icon_mostapplied"></div>
                    <div class="icon_text">
                        <a href="#">Most applied</a>

                    </div>
                </div>
            </div>
            <div class="icon_parent_holder">
                <div class="icon_holder">
                    <div class="icon_image"></div>
                    <div class="icon_text">
                        <a href="#">Most applied</a>

                    </div>
                </div>
            </div>
            <div class="icon_parent_holder">
                <div class="icon_holder">
                    <div class="icon_image"></div>
                    <div class="icon_text">
                        <a href="#">Most applied</a>

                    </div>
                </div>

            </div>
   </div>
    </body>
</html>
