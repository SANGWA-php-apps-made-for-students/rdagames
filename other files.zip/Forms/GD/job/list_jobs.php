<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="../../../webstyles/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="msg_holder">
            <div class="msg_warn" >

            </div>
        </div>

        <?php
        
        require_once '../db/multi_records.php';
        
        $jobs = multi_records::get_all_jobs();
           ?>

        <script src="../../js/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="../GD/admin_scripts.js" type="text/javascript"></script><!--
        -->


    </body>
</html>



