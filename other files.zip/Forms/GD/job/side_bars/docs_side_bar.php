<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="side_menu" id="doc_side_menu">
<!--                <div class="admin_menu">-->

                    <a id="newdoc" href="#"><span class="space_icon"><img src="../../images/file.png" align="center"></span>New </a><br/>
                    <a id="sharedoc" href="#"><span class="space_icon"><img src="../../images/sahre.png" align="center"></span>Share </a><br/>
                    <a id="removedoc" href="RemoveDoc.php"><span class="space_icon"><img src="../../images/remove.png" align="center"></span>Remove </a><br/>
<!--                                    <a id="newuser" href="newuser_role.php"><span class="space_icon"><img src="../images/remove.png" align="center"></span>Add new user category</a><br/>
                    <a id="" href="NewSpecial_User.php"><span class="space_icon"><img src="../../images/add.png" align="center"></span>Add new staff</a>-->

                <!--</div>-->
            </div>
        
    </body>
</html>
