<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div  class="side_menu" id="leave_side_bar">
            <a id="new_leae" href="#">   <span class="space_icon"><img src="../../images/file.png" align="center"></span>new leave </a><br/>
            <a id="all_leaves" href="#"><span class="space_icon"><img src="../../images/sahre.png" align="center"></span>leaves list </a><br/>
            <a id="admin_select_application" href="#">  <span class="space_icon"><img src="../../images/file.png" align="center"></span>leaves by department </a><br/>

            <a id="Job_reportst" href="RemoveDoc.php"><span class="space_icon"><img src="../../images/remove.png" align="center"></span>departments </a><br/>
        </div>
    </body>
</html>
