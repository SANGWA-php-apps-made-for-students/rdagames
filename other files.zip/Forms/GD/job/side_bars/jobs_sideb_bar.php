<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div  class="side_menu" id="job_side_bar">
            <a id="admin_newpost" href="#">   <span class="space_icon"><img src="../../images/file.png" align="center"></span>Post a new </a><br/>
            <a id="job_list_link" href="#"><span class="space_icon"><img src="../../images/sahre.png" align="center"></span>Jobs list </a><br/>
            <a id="job_select_application" href="#">  <span class="space_icon"><img src="../../images/file.png" align="center"></span>Select application </a><br/>

            <a id="Job_reportst_link" href="#"><span class="space_icon"><img src="../../images/remove.png" align="center"></span>Report </a><br/>
        </div>
    </body>
</html>
