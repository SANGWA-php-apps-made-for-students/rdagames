<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div  class="side_menu" id="webvisits_side_Bar">
            <a id="new_leae" href="#">   <span class="space_icon"><img src="../../images/file.png" align="center"></span>summary </a><br/>
            <a id="all_leaves" href="#"><span class="space_icon"><img src="../../images/sahre.png" align="center"></span>detailed </a><br/>
            <a id="admin_select_application" href="#">  <span class="space_icon"><img src="../../images/file.png" align="center"></span>search </a><br/>

            <a id="Job_reportst" href="RemoveDoc.php"><span class="space_icon"><img src="../../images/remove.png" align="center"></span>departments </a><br/>
        </div>
    </body>
</html>
