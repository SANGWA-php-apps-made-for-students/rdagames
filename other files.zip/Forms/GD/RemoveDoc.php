<?php
if (!isset($_SESSION)) {
    session_start();

    // 		if(!isset($_SESSION['admin'])){
    // 				header("location:../index.php");
    // }
    if (isset($_POST['send'])) {
        //save in the reservation
        $con = mysql_connect('localhost', 'usersuser', 'users@user!123') or die(mysql_error());
        mysql_select_db('usersmanagement')or die(mysql_error());
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            Remove documents
        </title>
        <link rel="stylesheet" type="text/css" href="../styles.css">
        <link rel="icon"  href="../images/rg_icon.png">
    </head>
    <body>
        <form action="Partners.php" method="post">

            <h2>Choose the document to remove</h2>

            <div style="float: right; width: 70%; background-color: #ced8d9; padding: 10px;
                 min-height: 100px; margin-right: 50px;
                 background: red; /* For browsers that do not support gradients */
                 background: -webkit-linear-gradient(#e6e6ff, #ccffcc); /* For Safari 5.1 to 6.0 */
                 background: -o-linear-gradient(#e6e6ff, #ccffcc); /* For Opera 11.1 to 12.0 */
                 background: -moz-linear-gradient(#e6e6ff, #ccffcc); /* For Firefox 3.6 to 15 */
                 background: linear-gradient(#e6e6ff, #ccffcc); /* Standard syntax */">
                <table>
                    <tr><td>Choose the document</td><td>
                            <select>

                                <?php
                                $con = mysql_connect('localhost', 'documentsuser', 'documents@user!123') or die(mysql_error('unable to login to db'));
                                mysql_select_db('Documentsdb')or die(mysql_error('unable to get the db'));
                                $query = "SELECT doc_name from documents ";
                                $res = mysql_query($query) or die(mysql_error());
                                while ($row = mysql_fetch_array($res)) {
                                    echo"

								 							<option value=" . $row['doc_name'] . ">" . $row['doc_name'] . "</option>"
                                    ;
                                }
                                ?>
                            </select>

                        </td></tr>
                </table>
                <input type="submit" name="send" value="Remove">
            </div>
        </form>
        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="scripts.js"></script>
    </body>
</html>