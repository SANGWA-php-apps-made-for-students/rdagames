<?php
if (!isset($_SESSION)) {
    session_start();
    // if(!isset($_SESSION['admin'])){
    // 		header("location:../index.php");
    // }

    if (isset($_POST['send'])) {
        
    }
}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>
            Partners
        </title>
        <link rel="stylesheet" type="text/css" href="../styles.css">
        <link rel="icon"  href="images/rg_icon.png">
    </head>
    <body>
        <form action="newuser_role.php" method="post">
            <?php
            if (isset($_POST['send'])) {
                //save in the reservation
                $rolename = $_POST['rolename'];
                $con = mysql_connect('localhost', 'usersuser', 'users@user!123') or die(mysql_error());
                mysql_select_db('usersmanagement')or die(mysql_error());
                $user_Id = $_SESSION['userid'];
                $query = "insert into users_category values(null,'$rolename')" or die(mysql_error());
                mysql_query($query)or die(mysql_error());
                mysql_close($con);
                echo "Data saved successfully";
            }
            ?>
            <div style="float: left; width: 55%; padding: 10px; min-height: 90px;
                 margin-left: 50px; margin-top: 30px;">
                <div class="pane_title">Add role(staff category)</div>
                <div class="pane_content">
                    <table>
                        <tr>
                            <td>role name:</td><td><input type="text" name="rolename"></td>
                        </tr>
                        <tr><td></td><td><input type="submit" name="send" value="Add"></td></tr>
                    </table>
                </div>
            </div>
            <div style="float: left;">
                <h3>Users types</h3>
                <table>
                    <tr style="background-color: #f2e6ff;">
                        <td>Name</td>
                    </tr>

                    <?php
                    $con = mysql_connect('localhost', 'usersuser', 'users@user!123') or die(mysql_error('unable to login to db'));
                    mysql_select_db('usersmanagement')or die(mysql_error('unable to get the db'));
                    $query = "SELECT category_name from users_category";
                    $res = mysql_query($query) or die(mysql_error());
                    while ($row = mysql_fetch_array($res)) {
                        ?>
                        <tr>
                            <td><?php echo $row['category_name']; ?></td>
                        <tr>
                    </table>
                <?php }
                ?>
            </div>


        </form>
        <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="scripts.js"></script>
    </body>
</html>