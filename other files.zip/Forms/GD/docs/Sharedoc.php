<?php 
if(!isset($_SESSION)) {
	session_start();
	
			// 	if(!isset($_SESSION['admin'])){
  	// 			header("location:../index.php");
				 
			// }
		 
	if (isset($_POST['send'])) {
		 
          //save in the reservation

		   
		    $con=mysql_connect('localhost','usersuser','users@user!123') or die(mysql_error());
		    mysql_select_db('usersmanagement')or die(mysql_error());
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Partners
	</title>
	<link rel="stylesheet" type="text/css" href="../styles.css">
	<link rel="icon"  href="../images/rg_icon.png">
</head>
<body>
<form action="Sharedoc.php" method="post">
	 
			<h2>Share some document with staff or other people</h2>
				 
					<div style="float: right; width: 70%; padding: 10px;
					 min-height: 100px; border: 4px ridge #4d4dff; margin-right: 50px;

					 	background: red; /* For browsers that do not support gradients */
					    background: -webkit-linear-gradient(#e6e6ff, #ccffcc); /* For Safari 5.1 to 6.0 */
					    background: -o-linear-gradient(#e6e6ff, #ccffcc); /* For Opera 11.1 to 12.0 */
					    background: -moz-linear-gradient(#e6e6ff, #ccffcc); /* For Firefox 3.6 to 15 */
					    background: linear-gradient(#e6e6ff, #ccffcc); /* Standard syntax */
					 ">
					<table>
						<tr>
							<td>Choose the type of person you want to share</td>
							<td>
								
									<select name="category_id">
							<option>
								<?php
											   	$con=mysql_connect('localhost','usersuser','users@user!123') or die(mysql_error('unable to login to db'));
											    	mysql_select_db('usersmanagement')or die(mysql_error('unable to get the db'));
												         $query="SELECT category_name from  users_category";
											       $res=mysql_query($query) or die(mysql_error());
											       while($row=mysql_fetch_array($res)){
							 							echo"

								 							<option value=".$row['category_name'].">".$row['category_name']."</option>"
								 							 ;
													}
												?>
							</option>
						</select>
							</td>
						</tr>
						<tr>
						<td>
							
							<input type="submit" name="send" value="Share">
						</td></tr>
					</table>
				 
	</div>
</form>
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="scripts.js"></script>
</body>
</html>