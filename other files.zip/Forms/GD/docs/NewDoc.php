<?php
session_start();

if (!isset($_SESSION['session_set'])) {
    header("location:../index.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>
            New documents
        </title>
        <link rel="stylesheet" type="text/css" href="../styles.css">
        <link rel="icon"  href="../images/rg_icon.png">
    </head>
    <body>
        <form action="NewDoc.php" method="post" enctype="multipart/form-data">
            <div style="width: 100%;"></div>
            
            <div class="all_sub_contents">
                content docs
            </div>

            <?php

            function uploadFTP($server, $username, $password, $local_file, $remote_file) {
                // connect to server
                $connection = ftp_connect($server);

                // login
                if (@ftp_login($connection, $username, $password)) {
                    // successfully connected
                } else {
                    return false;
                }

                ftp_put($connection, $remote_file, $local_file, FTP_BINARY);
                ftp_close($connection);
                return true;
            }

// $ftp_server = "rwandagames.co.rw";
// $ftp_conn = ftp_connect($ftp_server) or die("Could not connect to $ftp_server");



            if (isset($_POST['send'])) {

                uploadFTP("127.0.0.1", "rwandagames", "fTp@n4@Gm3z", "C:\\Users\\HP\\My Documents\\test_upload.txt", "docs/tuesday/test_upload.txt");
            }
            ?>



            <div style="float: left;   padding: 10px; min-height: 90px;
                 border: 1px ridge #4d4dff; margin-left: 30px;
                 background: red; /* For browsers that do not support gradients */
                 background: -webkit-linear-gradient(#cc99ff, #ccffcc); /* For Safari 5.1 to 6.0 */
                 background: -o-linear-gradient(#cc99ff, #ccffcc); /* For Opera 11.1 to 12.0 */
                 background: -moz-linear-gradient(#cc99ff, #ccffcc); /* For Firefox 3.6 to 15 */
                 background: linear-gradient(#cc99ff, #ccffcc); /* Standard syntax */">
                <input type="file" name="fileToUpload" id="fileToUpload">
                <input type="submit" name="send" value="upload">
                <div style="margin-top:45px;">
                    <h2 class="GoodLookingTitles">
                        List of documents
                    </h2>
                </div>
            </div>



        </div>

    </div>
</form>

</body>
</html>


