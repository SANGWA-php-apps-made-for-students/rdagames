<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="../webstyles/styles.css" rel="stylesheet" type="text/css"/>
        <link rel="icon" href="../images/rg_icon.png"> 
    </head>
    <body>
    <div class="header">
                    <div class="logo">

                    </div>	
                    <div class="title">
                        <span class="title_p1">RWANDA</span>
                        <span class="title_p2">GAMES</span>
                    </div>
                    <div class="login_register">
                        <div class="moving_text"><marquee>Gaming world</marquee></div>
                        <a href="../accounts/newuser.php">Register</a>
                        <a href="../accounts/login.php">Login</a>

                    </div>
                </div>
                <div class="menu">
                    <a id="home_link" href="../index.php" class="home_menu" >
                        Home</a>
                 <a href="Aboutus.php">About us</a>
                    <a href="news.php">News</a>
                    <a href="Gaming_centers.php">Gaming Centres</a>
                    <a href="carrier.php">Career</a>
                    <a href="Partners.php">Partners</a>
                    <a href="Contactus.php">Contact us</a>

                </div>
                <div class="two_pictures">
                    <a href="../Forms/mpeaceplazagallery.php">
                        <div class="pic1" name="pic1"></div>
                    </a>
                    <div class="pic2"></div>
                </div>

               
    </body>
</html>
