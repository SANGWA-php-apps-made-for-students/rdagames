<?php
if (!isset($_SESSION['session_set'])) {
    header("location:../../accounts/logout.php");
    //redirect to index
} 
?>
<!DOCTYPE html>
<html>
    <head> <meta charset="UTF-8">
        <title>Welcome to Rwanda Games Ltd</title>
   
        <link href="../../webstyles/styles.css" rel="stylesheet" type="text/css"/>
        <link href="pubstyles.css" rel="stylesheet" type="text/css"/>

        <link rel="icon" href="images/rg_icon.png">
          </head>
    <body>
        <form method="post" action="aboutus.php">
            <input type="hidden" name="userid" id="usernumber"  value="<?php echo $_SESSION['userid']; ?>" size="2" />
            <div class="All_overlay">

            </div>
            <div class="admin_dialog">
                <div class="dialog_msg">
                    Do you want to save 

                </div>
                <div class="dialog_cancel_btn">
                    <a href="#" id="dialog_cancel">OK</a>
                </div>
            </div>

            <div class="box">
                <div class="contents">
                    <div  class="pub_header">
                        <div class="admin_logo">
                        </div>	
                        <div class="pub_title">
                            <span class="title_p1">RWANDA</span>
                            <span class="title_p2">GAMES</span>
                        </div>

                    </div>

                    <div class="menu">
                        <a id="home_link" href="index.php" class="home_menu" >
                            Home</a>
                        <a href="Aboutus.php">About us</a>
                        <a href="news.php">News</a>
                        <a href="Gaming_centers.php">Gaming Centres</a>
                        <a href="carrier.php">Career</a>
                        <a href="Partners.php">Partners</a>
                        <a href="Contactus.php">Contact us</a>

                    </div> 
                    <div class="any_left_side"style=" margin-top: 20px;">Welcome,<?php
                        
                       require_once '../db/multi_records.php';
                        $names = $_SESSION['names'];
                        $id = $_SESSION['userid'];
                        echo $names;
                        ?>
                        <div style="margin:auto;text-align: center;text-align: left;  width: 100%; font-size: 12px; ">
                            You can get notifications from here
                            <span style="display: none;"  id="userid">
                                <?php echo $_SESSION['userid']; ?>
                            </span>
                        </div>
                    </div>

                    <div class="white_titles" style="font-size: 20px; margin-top: 10px;width: 100%;">users dashboard

                        <div  style="float:right; width:7%;
                              padding-left:5px; box-shadow: none;">
                            <a href="../../accounts/logout.php"><span class="space_icon">
                                    <img src="../../images/logout.png" align="center"></span>Logout</a>
                        </div>
                    </div>
                    <div class="users__hoz_menu" >
                        <a id="View_jobs" href="#">Jobs </a>
                        <a id="View_cv" href="#">My CV </a>
                        <!--                            <a id="staff_link" href="#">Staff</a>
                                                    <a id="visits_link" href="#">Web visits</a>
                                                    <a id="jobs_link" href="#">Jobs</a>-->

                    </div>
                    <div class="contents pub_contents">

                        <div class="users_message">

                        </div>
                        <div class="users_contents">
                            
                        </div>
                    </div>


                    <?php include('../footer.php'); ?> 
                </div>

        </form>
        <script src="../../js/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="pubscripts.js" type="text/javascript"></script>



    </body>
</html>