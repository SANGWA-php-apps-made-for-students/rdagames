

var usernumber, names, date_birth, residence, residence_city, national_id, sex, father, mother, nationality, language;
var grade, grade_name, edu_place, school_name;
var exp_title, exp_country, exp_state, exp_period, exp_year_or_month;
var sk_name, sk_place, sk_year;

var method1, method2, method3, method4;

$(document).ready(function () {

    jobs_clicked();
    cv_clicked();
    personal_addbutton();
    education_addbutton();
    experience_addbutton();
    skills_addbutton();
    send_cv_clicked();
    user_has_cv_not_applied();
    HideDialog();
    get_and_display_current_year();
    exp_period_year_month_selected();
    show_otherlanguage_textbox();
    English_or_french_checked();
    
    slider();
});


function jobs_clicked() {
    $('#View_jobs').click(function () {
        var path = '../GD/job/list_jobs.php';
        $('.pub_contents').load(path);
        return false;
    });
}

function cv_clicked() {
    $('#View_cv').click(function () {
        var path = 'mycv.php';
        $('.pub_contents').load(path);
        return false;
    });
}



function get_personal_data() {
    usernumber = $('#numberuser').val(),
            names = $('#names').val(),
            date_birth = $('#date_birth').val(),
            residence = $('#residence').val(),
            residence_city = $('#residence_city').val(),
            national_id = $('#national_id').val(),
            sex = $('#sex option:selected').text(),
            father = $('#father').val(),
            mother = $('#mother').val(),
            father = $('#father').val(),
            nationality = $('#nationality option:selected').text();
    language = '';
    if ($('#english').is(':checked') && $('#french').is(':checked')) {
        language = 'both';
    } else {
        if ($('#other').is(':checked')) {
            language = $('#other_textbox').val();
        } else {
            if ($('#french').is(':checked')) {
                language = 'french';
            } else {
                if ($('#english').is(':checked')) {
                    language = 'english';
                }


            }
        }
    }

}
function get_education_data() {
//now education
    grade = $('#education_grade').val(),
            grade_name = $('#education_grade_name').val(),
            edu_place = $('#education_place').val(),
            school_name = $('#education_school_name').val();
}
function get_experience_data() {
//experience
    exp_title = $('#experience_title').val(),
            exp_country = $('#experience_country option:selected').text(),
            exp_state = $('#experience_state').val(),
            exp_year_or_month = $('#exp_year_or_month option:selected').text();
    var period = $('#experience_period').val();
    var designation = exp_year_or_month;
    exp_period = period + ' ' + designation;

}
function get_skills_data() {
//skills
    sk_name = $('#skills_name').val(),
            sk_place = $('#skills_place').val(),
            sk_year = $('#skills_year').val();
}
function get_and_display_current_year() {//display current year in the textbox
    var dteNow = new Date();
    var intYear = dteNow.getFullYear();
    $('#skills_year').val(intYear);
}
function send_cv_clicked() {
    $('#send_cv, #send_cv2').click(function () {
        get_personal_data();
        get_education_data();
        get_experience_data();
        get_skills_data();

        if (date_birth == '') {
            $('#date_birth').css('background-color', '#ff0000');
        } else {
            if (exp_year_or_month == '') {
                $('#exp_year_or_month').css('background-color', '#ff0000');
            } else {
                $('#exp_year_or_month').css('background-color', '#fff');
                $('#date_birth').css('background-color', '#fff');
                if (language == '') {
                    alert('You have to choose the language');
                } else {
                    transfer_all();
                }

                return false;
            }
        }
        return false;
    });
}
function exp_period_year_month_selected() {
    var period_year_month = $('#exp_year_or_month').change(function () {
        if (period_year_month != '') {
            $('#exp_year_or_month').css('background-color', '#fff');
        }
        if (period_year_month == '') {
            $('#exp_year_or_month').css('background-color', '#ff0000');
        }
    });
}
function show_otherlanguage_textbox() {
    $('#other').on('change', function () {
        if ($(this).is(':checked')) {
            $('#other_textbox').attr('disabled', false);
            $('#english, #french').attr('checked', false);
        } else {
            $('#other_textbox').attr('disabled', true).val('');

        }

        return false;

    });
}
function English_or_french_checked() {
    $('#english, #french').on('change', function () {
        $('#other').attr('checked', false);
        $('#other_textbox').attr('disabled', true).val('');

    });
}
function transfer_all() {
    var method = 'newcv',
            request = 'new';
    $.post('../db/handler.php', {request: request, names: names,
        usernumber: usernumber, date_birth: date_birth,
        residence: residence, residence_city: residence_city, national_id: national_id,
        sex: sex, father: father, mother: mother,
        nationality: nationality, language: language, method: method,
        grade: grade, grade_name: grade_name, edu_place: edu_place, school_name: school_name,
        exp_title: exp_title, exp_country: exp_country, exp_state: exp_state, exp_period: exp_period,
        sk_name: sk_name, sk_place: sk_place, sk_year: sk_year},
            function (data) {
                if (data == 'Personal details are mandatory') {
                    alert(data);
                } else {
                    alert(data);
                }
            });
    return false;
}

function personal_addbutton() {
    $('#cv_add_personal').click(function () {

        var fields = $(' #date_birth, #residence, #national_id, #sex, #father, #mother, #nationality').val();
        fields = '';
        $('#date_birth, #residence, #national_id, #sex, #father, #mother, #nationality').val(fields);
        return false;
    });
}
function education_addbutton() {
    $('#cv_add_education').click(function () {
        var fields = $('#education_grade, #education_grade_name, #education_grade_name,#education_place, #education_school_name').val();
        fields = '';
        $('#education_grade, #education_grade_name, #education_grade_name,#education_place, #education_school_name').val(fields);
        return false;
    });
}
function skills_addbutton() {
    $('#cv_add_skills').click(function () {
        var fields = $('#skills_name, #skills_place, #skills_year').val();
        fields = '';
        $('#skills_name, #skills_place, #skills_year').val(fields);
        return false;
    });
}
function experience_addbutton() {
    $('#cv_add_experience').click(function () {
        var fields = $('#experience_title, #experience_country, #experience_state, #experience_period').val();
        fields = '';
        $('#experience_title, #experience_country, #experience_state, #experience_period').val(fields);
        return false;
    });
}

function user_has_noCv() {
    method2 = 'get_user_in_cv',
            request = 'uni';
    var userid = $('#userid').text();
    $.post('../db/handler.php', {request: request, user: userid}, function (data) {
        if (data == 'You have to fill in the cv first') {
            return false;
        } else {
            return true;
        }
    });
    //return false;
}

function user_has_cv_not_applied() {
    var userid = $('#userid').html(),
            method = 'get_if_applied',
            request = 'uni';
    $.post('../db/handler.php', {userid: userid, request: request, method: method}, function (data) {
        if (data != '') {
            $('.users_message').hide();
        } else {
            $('.users_message').html('You have filled your cv but have not applied to any job');

        }
    });

}

function Showdialog(msg) {
    $('.All_overlay').fadeIn(100);
    $('.admin_dialog').show().animate({marginTop: '200'});
    $('.dialog_msg').html(msg);
}
function HideDialog() {
    $('#dialog_cancel').click(function () {
        $('.All_overlay').fadeOut(100);
        $('.admin_dialog').animate({marginTop: '0'}).hide();
        return false;
    });
}

