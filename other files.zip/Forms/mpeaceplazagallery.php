<!DOCTYPE html>
<html>
<head>
	<title>
		Location
	</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<link rel="icon"  href="images/rg_icon.png">
	<?php
	$name='sangwa';

			session_start();
			echo $_SESSION['sent_pic'];
			 
		?>
</head>
<body>
<form action="Partners.php" method="post">
	<div class="box">

			 <div class="contents">
			 	<div class="header">
		<div class="logo">
		
		</div>	
		<div class="title">
			<span class="title_p1">RWANDA</span>
			<span class="title_p2">GAMES</span>
		</div>
		<div class="moving_text"><marquee>Gaming world</marquee></div>
		<div class="login_register">
			<a href="accounts/newuser.php" class="login_register">Register</a>
			<a href="accounts/login.php" class="login_register">login</a>
		</div>
	</div>
	<div class="menu">
		<a id="home_link" href="index.php" class="home_menu" >
				Home</a>
		<a href="Aboutus.php">About us</a>
		<a href="news.php">News</a>
		<a href="Gaming_centers.php">Gaming Centres</a>
		<a href="carrier.php">Career</a>
		<a href="Partners.php">Partners</a>
		<a href="Contactus.php">Contact us</a>
		
	</div>

			 	<div class="contents" style="overflow-y:auto;">
				<img class="plaza_images" src="images/plza_Cornerbottom.PNG" align="left" height="40%" width="40%">
				<img class="plaza_images" src="images/plaza_bottom_left.PNG" align="left" height="40%" width="40%">
				<img class="plaza_images" src="images/plaza_back_left.PNG" align="left" height="40%" width="40%">
				<img class="plaza_images" src="images/plaza_inside1.png" align="left" height="40%" width="40%">
				<img class="plaza_images" src="images/plaza_inside2.png" align="left" height="40%" width="40%">
			</div>
			 </div>
			
			<?php include('footer.php');?>
	</div>
</form>
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="scripts.js"></script>
 
<script type="text/javascript">
	$(document).ready(function(){
		$('a').click(function(){
				var link=$(this).attr('href');
				$.post('tracks/newtrack.php',{link: link},function(data){
			 		// $(".display").text('returned data is:  '+data);
			 		$('.contents').load(link);
			 			 		 
			 	});
			})
	});
</script>
</body>
</html>